package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.dao.TenantDAO;
import com.example.jamespropertysystem.model.Tenant;
import com.example.jamespropertysystem.util.Validator;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.example.jamespropertysystem.util.EmailService;
import javafx.fxml.FXML;
import com.example.jamespropertysystem.util.SessionManager;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class TenantController implements Initializable {

    @FXML private TableView<Tenant> tenantTable;
    @FXML private TableColumn<Tenant, String> idCol;
    @FXML private TableColumn<Tenant, String> nameCol;
    @FXML private TableColumn<Tenant, String> idNumberCol;
    @FXML private TableColumn<Tenant, String> phoneCol;
    @FXML private TableColumn<Tenant, String> emailCol;
    @FXML private TableColumn<Tenant, String> statusCol;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> statusFilterBox;
    @FXML private Label statusLabel;

    private TenantDAO tenantDAO = new TenantDAO();
    private ObservableList<Tenant> tenantList = FXCollections.observableArrayList();
    private List<Tenant> allTenants = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupTableColumns();
        statusFilterBox.setItems(FXCollections.observableArrayList(
                "All", "Active", "Blacklisted"));
        statusFilterBox.setValue("All");
        loadTenants();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.valueOf(d.getValue().getId())));
        nameCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getFullName()));
        idNumberCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getIdOrPassportNumber()));
        phoneCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getPhoneNumber()));
        emailCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getEmailAddress()));

        statusCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getStatus()));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    switch (item) {
                        case "Active" ->
                                setStyle("-fx-text-fill: #2e7d32; -fx-font-weight: bold;");
                        case "Blacklisted" ->//the arrows ?
                                setStyle("-fx-text-fill: #b71c1c; -fx-font-weight: bold;");
                        default -> setStyle("");
                    }
                }
            }
        });
    }

    private void loadTenants() {
        statusLabel.setText("Loading...");
        Thread thread = new Thread(() -> {//this
            allTenants = tenantDAO.getAllTenants();
          javafx.application.Platform.runLater(() -> {//tjis
                tenantList.setAll(allTenants);
                tenantTable.setItems(tenantList);
                statusLabel.setText("Total: " + allTenants.size() + " tenants");
            });
        });
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    private void handleSearch() {
        String search = searchField.getText().toLowerCase();
        tenantList.setAll(allTenants.stream()
                .filter(t -> t.getFullName().toLowerCase().contains(search)
                        || t.getIdOrPassportNumber().toLowerCase().contains(search)
                        || t.getEmailAddress().toLowerCase().contains(search))
                .toList());
        tenantTable.setItems(tenantList);
    }

    @FXML
    private void handleFilter() {
        String filter = statusFilterBox.getValue();
        tenantList.setAll(allTenants.stream()
                .filter(t -> filter == null || filter.equals("All")
                        || t.getStatus().equals(filter))
                .toList());
        tenantTable.setItems(tenantList);
        statusLabel.setText("Showing: " + tenantList.size() + " tenants");
    }

    @FXML
    private void handleAddTenant() {
        showTenantDialog(null);
    }

    @FXML
    private void handleEditTenant() {
        Tenant selected = tenantTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a tenant to edit.");
            return;
        }
        showTenantDialog(selected);
    }

    @FXML
    private void handleBlacklist() {
        Tenant selected = tenantTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a tenant.");
            return;
        }
        if (selected.getStatus().equals("Blacklisted")) {
            showInfo(selected.getFullName() + " is already blacklisted.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Blacklist Tenant");
        confirm.setHeaderText("Blacklist " + selected.getFullName() + "?");
        confirm.setContentText("This tenant will no longer be able to " +
                "create new leases.");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (tenantDAO.updateTenantStatus(selected.getId(), "Blacklisted")) {
                // Send blacklist notification email
                if (EmailService.isValidEmail(selected.getEmailAddress())) {
                    EmailService.sendBlacklistNotice(
                            selected.getEmailAddress(),
                            selected.getFullName()
                    );
                    statusLabel.setText(selected.getFullName()
                            + " has been blacklisted. Notification email sent.");
                } else {
                    statusLabel.setText(selected.getFullName() + " has been blacklisted.");
                }
                loadTenants();
            }
        }
    }

    @FXML
    private void handleActivate() {
        Tenant selected = tenantTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a tenant.");
            return;
        }
        if (selected.getStatus().equals("Active")) {
            showInfo(selected.getFullName() + " is already active.");
            return;
        }
        if (tenantDAO.updateTenantStatus(selected.getId(), "Active")) {
            loadTenants();
            statusLabel.setText(selected.getFullName() + " has been activated.");
        }
    }

    @FXML
    private void handleDeleteTenant() {
        Tenant selected = tenantTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a tenant to delete.");
            return;
        }

        TextInputDialog pwdDialog = new TextInputDialog();
        pwdDialog.setTitle("Admin Confirmation");
        pwdDialog.setHeaderText("🔐 Admin Password Required");
        pwdDialog.setContentText("Enter password to confirm delete:");
        Optional<String> pwdResult = pwdDialog.showAndWait();
        if (pwdResult.isEmpty() ||
                !SessionManager.verifyCurrentUserPassword(pwdResult.get().trim())) {
            statusLabel.setText("Incorrect password. Delete cancelled.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Tenant");
        confirm.setHeaderText("Delete " + selected.getFullName() + "?");
        confirm.setContentText("This action cannot be undone. " +
                "Tenant must have no active leases.");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (tenantDAO.deleteTenant(selected.getId())) {
                loadTenants();
                statusLabel.setText("Tenant deleted successfully.");
            } else {
                showError("Cannot delete this tenant. They may have " +
                        "active leases.\nPlease delete associated leases first.");
            }
        }
    }
    private boolean idExists(String idNumber, int excludeId) {
        return tenantDAO.getAllTenants().stream()
                .filter(t -> t.getId() != excludeId)
                .anyMatch(t -> t.getIdOrPassportNumber()
                        .equalsIgnoreCase(idNumber));
    }

    private void showTenantDialog(Tenant existing) {
        Dialog<Tenant> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add New Tenant" : "Edit Tenant");
        dialog.setHeaderText(existing == null
                ? "Fill in the tenant details below"
                : "Update tenant details");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField firstNameField = new TextField();
        TextField lastNameField = new TextField();
        TextField idNumberField = new TextField();
        TextField phoneField = new TextField();
        TextField emailField = new TextField();
        ComboBox<String> statusBox = new ComboBox<>(
                FXCollections.observableArrayList("Active", "Blacklisted"));

        firstNameField.setPromptText("e.g. John");
        lastNameField.setPromptText("e.g. Smith");
        idNumberField.setPromptText("e.g. 9801234567890");
        phoneField.setPromptText("e.g. +264 81 234 5678");
        emailField.setPromptText("e.g. john@email.com");

        if (existing != null) {
            firstNameField.setText(existing.getFirstName());
            lastNameField.setText(existing.getLastName());
            idNumberField.setText(existing.getIdOrPassportNumber());
            phoneField.setText(existing.getPhoneNumber());
            emailField.setText(existing.getEmailAddress());
            statusBox.setValue(existing.getStatus());
        } else {
            statusBox.setValue("Active");
        }

        grid.add(new Label("First Name:*"), 0, 0); grid.add(firstNameField, 1, 0);
        grid.add(new Label("Last Name:*"), 0, 1); grid.add(lastNameField, 1, 1);
        grid.add(new Label("ID/Passport:*"), 0, 2); grid.add(idNumberField, 1, 2);
        grid.add(new Label("Phone:*"), 0, 3); grid.add(phoneField, 1, 3);
        grid.add(new Label("Email:*"), 0, 4); grid.add(emailField, 1, 4);
        grid.add(new Label("Status:"), 0, 5); grid.add(statusBox, 1, 5);

        Label note = new Label("* Required fields");
        note.setStyle("-fx-text-fill: #78909c; -fx-font-size: 11px;");
        grid.add(note, 1, 6);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(420);



        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                String firstName = firstNameField.getText().trim();
                String lastName = lastNameField.getText().trim();
                String idNumber = idNumberField.getText().trim();
                String phone = phoneField.getText().trim();
                String email = emailField.getText().trim();

                // Validate first name
                if (!Validator.isValidName(firstName)) {
                    showError(Validator.getNameError("First name"));
                    return null;
                }
                // Validate last name
                if (!Validator.isValidName(lastName)) {
                    showError(Validator.getNameError("Last name"));
                    return null;
                }
                // Validate ID/Passport
                if (!Validator.isValidIdNumber(idNumber)) {
                    showError(Validator.getIdError());
                    return null;
                }
                // Validate phone
                if (!Validator.isValidPhone(phone)) {
                    showError(Validator.getPhoneError());
                    return null;
                }
                // Validate email
                if (!Validator.isValidEmail(email)) {
                    showError("Please enter a valid email address (e.g. name@example.com).");
                    return null;
                }
                // Check duplicate email
                int currentId = existing != null ? existing.getId() : 0;
                if (tenantDAO.emailExists(email, currentId)) {
                    showError("This email address is already registered to another tenant.");
                    return null;
                }
                // Check duplicate ID/Passport
                if (idExists(idNumber, currentId)) {
                    showError("This ID/Passport number is already registered to another tenant.");
                    return null;
                }

                return new Tenant(
                        existing != null ? existing.getId() : 0,
                        firstName,
                        lastName,
                        idNumber,
                        phone,
                        email,
                        statusBox.getValue()
                );
            }
            return null;
        });

        Optional<Tenant> result = dialog.showAndWait();
        result.ifPresent(tenant -> {
            if (tenant == null) return;
            boolean success;
            if (existing == null) {
                success = tenantDAO.addTenant(tenant);
                if (success) {
                    loadTenants();
                    statusLabel.setText("Tenant added successfully.");
                } else {
                    showError("Failed to add tenant. " +
                            "ID/Passport number may already exist.");
                }
            } else {
                success = tenantDAO.updateTenant(tenant);
                if (success) {
                    loadTenants();
                    statusLabel.setText("Tenant updated successfully.");
                } else {
                    showError("Failed to update tenant.");
                }
            }
        });
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}