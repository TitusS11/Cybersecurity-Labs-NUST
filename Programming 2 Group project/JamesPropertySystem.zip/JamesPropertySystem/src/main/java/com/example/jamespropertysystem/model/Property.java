package com.example.jamespropertysystem.model;

public abstract class Property {

    private int id;
    private String propertyType;
    private double buildingFloorSize;
    private String address;
    private String erfNumber;
    private String location;
    private double marketValue;
    private double monthlyRentalCost;
    private String availabilityStatus;

    public Property() {}

    public Property(int id, String propertyType, double buildingFloorSize, String address,
                    String erfNumber, String location, double marketValue,
                    double monthlyRentalCost, String availabilityStatus) {
        this.id = id;
        this.propertyType = propertyType;
        this.buildingFloorSize = buildingFloorSize;
        this.address = address;
        this.erfNumber = erfNumber;
        this.location = location;
        this.marketValue = marketValue;
        this.monthlyRentalCost = monthlyRentalCost;
        this.availabilityStatus = availabilityStatus;
    }

    // Abstract method - each subclass must implement this
    public abstract String getTypeSpecificDetails();

    public double calculateAnnualRental() {
        return monthlyRentalCost * 12;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPropertyType() { return propertyType; }
    public void setPropertyType(String propertyType) { this.propertyType = propertyType; }

    public double getBuildingFloorSize() { return buildingFloorSize; }
    public void setBuildingFloorSize(double buildingFloorSize) { this.buildingFloorSize = buildingFloorSize; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getErfNumber() { return erfNumber; }
    public void setErfNumber(String erfNumber) { this.erfNumber = erfNumber; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public double getMarketValue() { return marketValue; }
    public void setMarketValue(double marketValue) { this.marketValue = marketValue; }

    public double getMonthlyRentalCost() { return monthlyRentalCost; }
    public void setMonthlyRentalCost(double monthlyRentalCost) { this.monthlyRentalCost = monthlyRentalCost; }

    public String getAvailabilityStatus() { return availabilityStatus; }
    public void setAvailabilityStatus(String availabilityStatus) { this.availabilityStatus = availabilityStatus; }

    @Override
    public String toString() {
        return "[" + propertyType + "] " + address + " - " + availabilityStatus;
    }
}
