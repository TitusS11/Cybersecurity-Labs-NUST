package com.example.jamespropertysystem.dao;

import com.example.jamespropertysystem.database.DBConnection;
import com.example.jamespropertysystem.model.Payment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    public boolean addPayment(Payment payment) {
        String sql = "INSERT INTO payments (lease_id, amount_paid, payment_date, " +
                "status, penalty_amount, outstanding_balance) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, payment.getLeaseId());
            stmt.setDouble(2, payment.getAmountPaid());
            stmt.setDate(3, Date.valueOf(payment.getPaymentDate()));
            stmt.setString(4, payment.getStatus());
            stmt.setDouble(5, payment.getPenaltyAmount());
            stmt.setDouble(6, payment.getOutstandingBalance());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding payment: " + e.getMessage());
            return false;
        }
    }

    public List<Payment> getAllPayments() {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT pay.*, t.first_name, t.last_name, p.address " +
                "FROM payments pay " +
                "JOIN leases l ON pay.lease_id = l.id " +
                "JOIN tenants t ON l.tenant_id = t.id " +
                "JOIN properties p ON l.property_id = p.id";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Payment payment = mapResultSetToPayment(rs);
                payment.setTenantName(rs.getString("first_name") + " " + rs.getString("last_name"));
                payment.setPropertyAddress(rs.getString("address"));
                payments.add(payment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching payments: " + e.getMessage());
        }
        return payments;
    }

    public List<Payment> getPaymentsByLease(int leaseId) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT pay.*, t.first_name, t.last_name, p.address " +
                "FROM payments pay " +
                "JOIN leases l ON pay.lease_id = l.id " +
                "JOIN tenants t ON l.tenant_id = t.id " +
                "JOIN properties p ON l.property_id = p.id " +
                "WHERE pay.lease_id = ?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, leaseId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Payment payment = mapResultSetToPayment(rs);
                payment.setTenantName(rs.getString("first_name") + " " + rs.getString("last_name"));
                payment.setPropertyAddress(rs.getString("address"));
                payments.add(payment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching payments by lease: " + e.getMessage());
        }
        return payments;
    }

    public List<Payment> getOverduePayments() {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT pay.*, t.first_name, t.last_name, p.address " +
                "FROM payments pay " +
                "JOIN leases l ON pay.lease_id = l.id " +
                "JOIN tenants t ON l.tenant_id = t.id " +
                "JOIN properties p ON l.property_id = p.id " +
                "WHERE pay.status = 'Late' OR pay.outstanding_balance > 0";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Payment payment = mapResultSetToPayment(rs);
                payment.setTenantName(rs.getString("first_name") + " " + rs.getString("last_name"));
                payment.setPropertyAddress(rs.getString("address"));
                payments.add(payment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching overdue payments: " + e.getMessage());
        }
        return payments;
    }

    public double getTotalRevenueByMonth(int month, int year) {
        String sql = "SELECT COALESCE(SUM(amount_paid), 0) FROM payments " +
                "WHERE EXTRACT(MONTH FROM payment_date) = ? " +
                "AND EXTRACT(YEAR FROM payment_date) = ? " +
                "AND status != 'Pending'";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, month);
            stmt.setInt(2, year);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("Error calculating monthly revenue: " + e.getMessage());
        }
        return 0;
    }

    public double getTotalRevenueByYear(int year) {
        String sql = "SELECT COALESCE(SUM(amount_paid), 0) FROM payments " +
                "WHERE EXTRACT(YEAR FROM payment_date) = ? " +
                "AND status != 'Pending'";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, year);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("Error calculating annual revenue: " + e.getMessage());
        }
        return 0;
    }

    public boolean updatePayment(Payment payment) {
        String sql = "UPDATE payments SET amount_paid=?, payment_date=?, status=?, " +
                "penalty_amount=?, outstanding_balance=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setDouble(1, payment.getAmountPaid());
            stmt.setDate(2, Date.valueOf(payment.getPaymentDate()));
            stmt.setString(3, payment.getStatus());
            stmt.setDouble(4, payment.getPenaltyAmount());
            stmt.setDouble(5, payment.getOutstandingBalance());
            stmt.setInt(6, payment.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating payment: " + e.getMessage());
            return false;
        }
    }

    private Payment mapResultSetToPayment(ResultSet rs) throws SQLException {
        return new Payment(
                rs.getInt("id"),
                rs.getInt("lease_id"),
                rs.getDouble("amount_paid"),
                rs.getDate("payment_date").toLocalDate(),
                rs.getString("status"),
                rs.getDouble("penalty_amount"),
                rs.getDouble("outstanding_balance")
        );
    }
}
