package com.example.jamespropertysystem.model;

public class FlatApartment extends Property {

    private String unitNumber;
    private int floorLevel;
    private boolean hasElevatorAccess;
    private boolean hasBackyard;

    public FlatApartment() {}

    public FlatApartment(int id, double buildingFloorSize, String address, String erfNumber,
                         String location, double marketValue, double monthlyRentalCost,
                         String availabilityStatus, String unitNumber, int floorLevel,
                         boolean hasElevatorAccess, boolean hasBackyard) {
        super(id, "FlatApartment", buildingFloorSize, address, erfNumber, location,
                marketValue, monthlyRentalCost, availabilityStatus);
        this.unitNumber = unitNumber;
        this.floorLevel = floorLevel;
        this.hasElevatorAccess = hasElevatorAccess;
        this.hasBackyard = hasBackyard;
    }

    @Override
    public String getTypeSpecificDetails() {
        return "Unit: " + unitNumber + " | Floor: " + floorLevel +
                " | Elevator: " + (hasElevatorAccess ? "Yes" : "No") +
                " | Backyard: " + (hasBackyard ? "Yes" : "No");
    }

    public String getUnitNumber() { return unitNumber; }
    public void setUnitNumber(String unitNumber) { this.unitNumber = unitNumber; }

    public int getFloorLevel() { return floorLevel; }
    public void setFloorLevel(int floorLevel) { this.floorLevel = floorLevel; }

    public boolean isHasElevatorAccess() { return hasElevatorAccess; }
    public void setHasElevatorAccess(boolean hasElevatorAccess) { this.hasElevatorAccess = hasElevatorAccess; }

    public boolean isHasBackyard() { return hasBackyard; }
    public void setHasBackyard(boolean hasBackyard) { this.hasBackyard = hasBackyard; }
}
