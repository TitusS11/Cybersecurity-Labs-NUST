package com.example.jamespropertysystem.model;

public class Townhouse extends Property {

    private String unitNumber;
    private boolean hasBackyard;

    public Townhouse() {}

    public Townhouse(int id, double buildingFloorSize, String address, String erfNumber,
                     String location, double marketValue, double monthlyRentalCost,
                     String availabilityStatus, String unitNumber, boolean hasBackyard) {
        super(id, "Townhouse", buildingFloorSize, address, erfNumber, location,
                marketValue, monthlyRentalCost, availabilityStatus);
        this.unitNumber = unitNumber;
        this.hasBackyard = hasBackyard;
    }

    @Override
    public String getTypeSpecificDetails() {
        return "Unit: " + unitNumber + " | Backyard: " + (hasBackyard ? "Yes" : "No");
    }

    public String getUnitNumber() { return unitNumber; }
    public void setUnitNumber(String unitNumber) { this.unitNumber = unitNumber; }

    public boolean isHasBackyard() { return hasBackyard; }
    public void setHasBackyard(boolean hasBackyard) { this.hasBackyard = hasBackyard; }
}