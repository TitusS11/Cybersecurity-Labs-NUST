package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.dao.LeaseDAO;
import com.example.jamespropertysystem.dao.PropertyDAO;
import com.example.jamespropertysystem.dao.TenantDAO;
import com.example.jamespropertysystem.model.Lease;
import com.example.jamespropertysystem.model.Property;
import com.example.jamespropertysystem.model.Tenant;
import com.example.jamespropertysystem.util.SessionManager;
import com.example.jamespropertysystem.util.EmailService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class LeaseController implements Initializable {

    @FXML private TableView<Lease> leaseTable;
    @FXML private TableColumn<Lease, String> idCol;
    @FXML private TableColumn<Lease, String> tenantCol;
    @FXML private TableColumn<Lease, String> propertyCol;
    @FXML private TableColumn<Lease, String> startCol;
    @FXML private TableColumn<Lease, String> endCol;
    @FXML private TableColumn<Lease, String> rentCol;
    @FXML private TableColumn<Lease, String> depositCol;
    @FXML private TableColumn<Lease, String> durationCol;
    @FXML private Label statusLabel;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> filterBox;

    private LeaseDAO leaseDAO = new LeaseDAO();
    private PropertyDAO propertyDAO = new PropertyDAO();
    private TenantDAO tenantDAO = new TenantDAO();
    private ObservableList<Lease> leaseList = FXCollections.observableArrayList();
    private List<Lease> allLeases = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupTableColumns();
        filterBox.setItems(FXCollections.observableArrayList(
                "All", "Active", "Expired"));
        filterBox.setValue("All");
        loadLeases();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.valueOf(d.getValue().getId())));
        tenantCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getTenantName()));
        propertyCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getPropertyAddress()));
        startCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getStartDate().toString()));
        endCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getEndDate().toString()));
        rentCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getMonthlyRentAmount())));
        depositCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getSecurityDeposit())));
        durationCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getLeaseDurationInMonths() + " months"));
    }

    private void loadLeases() {
        statusLabel.setText("Loading...");
        Thread thread = new Thread(() -> {
            allLeases = leaseDAO.getAllLeases();
            javafx.application.Platform.runLater(() -> {
                leaseList.setAll(allLeases);
                leaseTable.setItems(leaseList);
                statusLabel.setText("Total: " + allLeases.size() + " leases");
            });
        });
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    private void handleSearch() {
        String search = searchField.getText().toLowerCase();
        leaseList.setAll(allLeases.stream()
                .filter(l -> l.getTenantName().toLowerCase().contains(search)
                        || l.getPropertyAddress().toLowerCase().contains(search))
                .toList());
        leaseTable.setItems(leaseList);
    }

    @FXML
    private void handleFilter() {
        String filter = filterBox.getValue();
        leaseList.setAll(allLeases.stream()
                .filter(l -> {
                    if (filter == null || filter.equals("All")) return true;
                    if (filter.equals("Active")) return l.isActive(LocalDate.now());
                    if (filter.equals("Expired")) return !l.isActive(LocalDate.now());
                    return true;
                })
                .toList());
        leaseTable.setItems(leaseList);
        statusLabel.setText("Showing: " + leaseList.size() + " leases");
    }

    @FXML
    private void handleAddLease() {
        List<Property> availableProperties = propertyDAO.getAvailableProperties();
        List<Tenant> activeTenants = tenantDAO.getAllTenants().stream()
                .filter(t -> t.getStatus().equals("Active")).toList();

        if (availableProperties.isEmpty()) {
            showInfo("No available properties to lease.");
            return;
        }
        if (activeTenants.isEmpty()) {
            showInfo("No active tenants found. Please add a tenant first.\n" +
                    "Note: Blacklisted tenants cannot create leases.");
            return;
        }

        // Store selected property reference for email
        Property[] selectedPropertyRef = {null};

        Dialog<Lease> dialog = createLeaseDialog(
                null, availableProperties, activeTenants, selectedPropertyRef);
        Optional<Lease> result = dialog.showAndWait();

        result.ifPresent(lease -> {
            if (lease == null) return;

            Tenant tenant = tenantDAO.getTenantById(lease.getTenantId());
            if (tenant != null && tenant.getStatus().equals("Blacklisted")) {
                showError("Cannot create lease for a blacklisted tenant.");
                return;
            }

            if (leaseDAO.isPropertyOccupied(lease.getPropertyId())) {
                showError("This property is already occupied.");
                return;
            }

            if (leaseDAO.addLease(lease)) {
                propertyDAO.updateAvailabilityStatus(
                        lease.getPropertyId(), "Occupied");

                // Get property address for email
                String propertyAddress = selectedPropertyRef[0] != null
                        ? selectedPropertyRef[0].getAddress()
                        : propertyDAO.getAllProperties().stream()
                          .filter(p -> p.getId() == lease.getPropertyId())
                          .findFirst()
                          .map(Property::getAddress)
                          .orElse("Your property");

                // Send lease confirmation email
                if (tenant != null && tenant.getEmailAddress() != null
                        && !tenant.getEmailAddress().isEmpty()) {
                    EmailService.sendLeaseConfirmation(
                            tenant.getEmailAddress(),
                            tenant.getFullName(),
                            propertyAddress,
                            lease.getStartDate().toString(),
                            lease.getEndDate().toString(),
                            lease.getMonthlyRentAmount(),
                            lease.getSecurityDeposit()
                    );
                    statusLabel.setText("Lease created. Confirmation email sent to "
                            + tenant.getEmailAddress());
                } else {
                    statusLabel.setText("Lease created successfully.");
                }
                loadLeases();
            } else {
                showError("Failed to create lease. Please try again.");
            }
        });
    }

    @FXML
    private void handleEditLease() {
        Lease selected = leaseTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a lease to edit.");
            return;
        }
        List<Property> allProperties = propertyDAO.getAllProperties();
        List<Tenant> allTenants = tenantDAO.getAllTenants();
        Dialog<Lease> dialog = createLeaseDialog(
                selected, allProperties, allTenants, new Property[]{null});
        Optional<Lease> result = dialog.showAndWait();
        result.ifPresent(lease -> {
            if (lease == null) return;
            if (leaseDAO.updateLease(lease)) {
                loadLeases();
                statusLabel.setText("Lease updated successfully.");
            } else {
                showError("Failed to update lease.");
            }
        });
    }

    @FXML
    private void handleTerminate() {
        Lease selected = leaseTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a lease to terminate.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Terminate Lease");
        confirm.setHeaderText("Terminate lease for " + selected.getTenantName() + "?");
        confirm.setContentText("This will set the end date to today and " +
                "mark the property as Available.");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (leaseDAO.terminateLease(selected.getId(), LocalDate.now())) {
                propertyDAO.updateAvailabilityStatus(
                        selected.getPropertyId(), "Available");

                // Send termination notice email
                Tenant tenant = tenantDAO.getTenantById(selected.getTenantId());
                if (tenant != null && tenant.getEmailAddress() != null
                        && !tenant.getEmailAddress().isEmpty()) {
                    EmailService.sendTerminationNotice(
                            tenant.getEmailAddress(),
                            tenant.getFullName(),
                            selected.getPropertyAddress(),
                            LocalDate.now().toString()
                    );
                }
                loadLeases();
                statusLabel.setText("Lease terminated. Notice email sent to tenant.");
            }
        }
    }

    @FXML
    private void handleGeneratePDF() {
        Lease selected = leaseTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a lease to generate PDF.");
            return;
        }
        try {
            String filename = "Lease_Contract_" + selected.getId() + ".pdf";
            com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            com.itextpdf.text.pdf.PdfWriter.getInstance(document,
                    new java.io.FileOutputStream(filename));

            com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 18,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 12,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font normalFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 11);

            document.open();
            document.add(new com.itextpdf.text.Paragraph(
                    "JAMES PROPERTY HOLDINGS", titleFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "LEASE AGREEMENT", headerFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "Lease ID: " + selected.getId(), headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Tenant: " + selected.getTenantName(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Property: " + selected.getPropertyAddress(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "LEASE TERMS:", headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Start Date:       " + selected.getStartDate(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "End Date:         " + selected.getEndDate(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Duration:         " + selected.getLeaseDurationInMonths()
                            + " months", normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Monthly Rent:     N$" + String.format("%.2f",
                            selected.getMonthlyRentAmount()), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Security Deposit: N$" + String.format("%.2f",
                            selected.getSecurityDeposit()), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Payment Due Day:  " + selected.getPaymentDueDay()
                            + " of each month", normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Grace Period:     " + selected.getGracePeriodDays()
                            + " days", normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Late Penalty:     " + selected.getLatePenaltyRule(),
                    normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            document.add(new com.itextpdf.text.Paragraph(
                    "Generated: " + LocalDate.now(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "James Property Holdings | Windhoek, Namibia", normalFont));
            document.close();
            statusLabel.setText("PDF saved: " + filename);
            showInfo("Lease contract generated!\nSaved as: " + filename);
        } catch (Exception e) {
            showError("Error generating PDF: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteLease() {
        Lease selected = leaseTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a lease to delete.");
            return;
        }

        TextInputDialog pwdDialog = new TextInputDialog();
        pwdDialog.setTitle("Admin Confirmation");
        pwdDialog.setHeaderText("🔐 Admin Password Required");
        pwdDialog.setContentText("Enter password to confirm delete:");
        Optional<String> pwdResult = pwdDialog.showAndWait();
        if (pwdResult.isEmpty() ||
                !SessionManager.verifyCurrentUserPassword(pwdResult.get().trim())) {
            statusLabel.setText("Incorrect password. Delete cancelled.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Lease");
        confirm.setHeaderText("Delete lease for " + selected.getTenantName() + "?");
        confirm.setContentText("This will also delete all payment records " +
                "linked to this lease. This cannot be undone.");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                java.sql.Connection conn =
                        com.example.jamespropertysystem.database.DBConnection
                                .getConnection();
                java.sql.PreparedStatement deletePayments = conn.prepareStatement(
                        "DELETE FROM payments WHERE lease_id = ?");
                deletePayments.setInt(1, selected.getId());
                deletePayments.executeUpdate();

                java.sql.PreparedStatement deleteLease = conn.prepareStatement(
                        "DELETE FROM leases WHERE id = ?");
                deleteLease.setInt(1, selected.getId());
                deleteLease.executeUpdate();

                propertyDAO.updateAvailabilityStatus(
                        selected.getPropertyId(), "Available");
                loadLeases();
                statusLabel.setText("Lease deleted successfully.");
            } catch (java.sql.SQLException e) {
                showError("Error deleting lease: " + e.getMessage());
            }
        }
    }

    private Dialog<Lease> createLeaseDialog(Lease existing,
                                            List<Property> properties,
                                            List<Tenant> tenants,
                                            Property[] selectedPropertyRef) {
        Dialog<Lease> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "New Lease" : "Edit Lease");
        dialog.setHeaderText(existing == null
                ? "Create a new lease agreement"
                : "Update lease details");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        ComboBox<Property> propertyBox = new ComboBox<>(
                FXCollections.observableArrayList(properties));
        ComboBox<Tenant> tenantBox = new ComboBox<>(
                FXCollections.observableArrayList(tenants));
        DatePicker startPicker = new DatePicker(LocalDate.now());
        DatePicker endPicker = new DatePicker(LocalDate.now().plusYears(1));
        TextField rentField = new TextField();
        TextField depositField = new TextField();
        TextField dueDayField = new TextField("1");
        TextField gracePeriodField = new TextField("5");
        TextField penaltyField = new TextField("10% of monthly rent");

        rentField.setPromptText("e.g. 5500");
        depositField.setPromptText("e.g. 11000");

        // Auto fill rent and store selected property ref
        propertyBox.setOnAction(e -> {
            Property selected = propertyBox.getValue();
            if (selected != null) {
                selectedPropertyRef[0] = selected;
                rentField.setText(String.valueOf(selected.getMonthlyRentalCost()));
                depositField.setText(String.format("%.2f",
                        selected.getMonthlyRentalCost() * 2));
            }
        });

        if (existing != null) {
            rentField.setText(String.valueOf(existing.getMonthlyRentAmount()));
            depositField.setText(String.valueOf(existing.getSecurityDeposit()));
            dueDayField.setText(String.valueOf(existing.getPaymentDueDay()));
            gracePeriodField.setText(String.valueOf(existing.getGracePeriodDays()));
            penaltyField.setText(existing.getLatePenaltyRule());
            startPicker.setValue(existing.getStartDate());
            endPicker.setValue(existing.getEndDate());
        }

        grid.add(new Label("Property:*"), 0, 0); grid.add(propertyBox, 1, 0);
        grid.add(new Label("Tenant:*"), 0, 1); grid.add(tenantBox, 1, 1);
        grid.add(new Label("Start Date:*"), 0, 2); grid.add(startPicker, 1, 2);
        grid.add(new Label("End Date:*"), 0, 3); grid.add(endPicker, 1, 3);
        grid.add(new Label("Monthly Rent (N$):*"), 0, 4); grid.add(rentField, 1, 4);
        grid.add(new Label("Security Deposit (N$):*"), 0, 5);
        grid.add(depositField, 1, 5);
        grid.add(new Label("Payment Due Day:"), 0, 6); grid.add(dueDayField, 1, 6);
        grid.add(new Label("Grace Period (days):"), 0, 7);
        grid.add(gracePeriodField, 1, 7);
        grid.add(new Label("Late Penalty Rule:"), 0, 8); grid.add(penaltyField, 1, 8);

        Label note = new Label(
                "* Required | Rent auto-fills when property selected");
        note.setStyle("-fx-text-fill: #78909c; -fx-font-size: 11px;");
        grid.add(note, 0, 9, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(450);

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                Property selectedProperty = propertyBox.getValue();
                Tenant selectedTenant = tenantBox.getValue();

                if (selectedProperty == null) {
                    showError("Please select a property.");
                    return null;
                }
                if (selectedTenant == null) {
                    showError("Please select a tenant.");
                    return null;
                }
                if (selectedTenant.getStatus().equals("Blacklisted")) {
                    showError("Cannot create a lease for a blacklisted tenant.");
                    return null;
                }
                if (rentField.getText().trim().isEmpty()) {
                    showError("Monthly rent is required.");
                    return null;
                }
                if (depositField.getText().trim().isEmpty()) {
                    showError("Security deposit is required.");
                    return null;
                }
                if (startPicker.getValue().isAfter(endPicker.getValue())) {
                    showError("Start date must be before end date.");
                    return null;
                }
                try {
                    selectedPropertyRef[0] = selectedProperty;
                    return new Lease(
                            existing != null ? existing.getId() : 0,
                            selectedProperty.getId(),
                            selectedTenant.getId(),
                            startPicker.getValue(),
                            endPicker.getValue(),
                            Double.parseDouble(rentField.getText().trim()),
                            Double.parseDouble(depositField.getText().trim()),
                            Integer.parseInt(dueDayField.getText().trim()),
                            Integer.parseInt(gracePeriodField.getText().trim()),
                            penaltyField.getText().trim()
                    );
                } catch (NumberFormatException e) {
                    showError("Please enter valid numbers for rent, " +
                            "deposit, due day and grace period.");
                    return null;
                }
            }
            return null;
        });
        return dialog;
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}