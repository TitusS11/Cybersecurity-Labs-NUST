package com.example.jamespropertysystem.dao;

import com.example.jamespropertysystem.database.DBConnection;
import com.example.jamespropertysystem.model.Tenant;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TenantDAO {

    public boolean addTenant(Tenant tenant) {
        String sql = "INSERT INTO tenants (first_name, last_name, id_or_passport_number, " +
                "phone_number, email_address, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, tenant.getFirstName());
            stmt.setString(2, tenant.getLastName());
            stmt.setString(3, tenant.getIdOrPassportNumber());
            stmt.setString(4, tenant.getPhoneNumber());
            stmt.setString(5, tenant.getEmailAddress());
            stmt.setString(6, tenant.getStatus());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding tenant: " + e.getMessage());
            return false;
        }
    }

    public List<Tenant> getAllTenants() {
        List<Tenant> tenants = new ArrayList<>();
        String sql = "SELECT * FROM tenants";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tenants.add(mapResultSetToTenant(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching tenants: " + e.getMessage());
        }
        return tenants;
    }

    public Tenant getTenantById(int id) {
        String sql = "SELECT * FROM tenants WHERE id = ?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToTenant(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching tenant: " + e.getMessage());
        }
        return null;
    }

    public boolean updateTenant(Tenant tenant) {
        String sql = "UPDATE tenants SET first_name=?, last_name=?, id_or_passport_number=?, " +
                "phone_number=?, email_address=?, status=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, tenant.getFirstName());
            stmt.setString(2, tenant.getLastName());
            stmt.setString(3, tenant.getIdOrPassportNumber());
            stmt.setString(4, tenant.getPhoneNumber());
            stmt.setString(5, tenant.getEmailAddress());
            stmt.setString(6, tenant.getStatus());
            stmt.setInt(7, tenant.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating tenant: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteTenant(int id) {
        String sql = "DELETE FROM tenants WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting tenant: " + e.getMessage());
            return false;
        }
    }
    public boolean emailExists(String email, int excludeId) {
        String sql = "SELECT COUNT(*) FROM tenants WHERE email_address = ? AND id != ?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setInt(2, excludeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("Error checking email: " + e.getMessage());
        }
        return false;
    }
    public boolean updateTenantStatus(int tenantId, String status) {
        String sql = "UPDATE tenants SET status=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, tenantId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating tenant status: " + e.getMessage());
            return false;
        }
    }

    private Tenant mapResultSetToTenant(ResultSet rs) throws SQLException {
        return new Tenant(
                rs.getInt("id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("id_or_passport_number"),
                rs.getString("phone_number"),
                rs.getString("email_address"),
                rs.getString("status")
        );
    }
}