package com.example.jamespropertysystem.model;

public class Tenant {

    private int id;
    private String firstName;
    private String lastName;
    private String idOrPassportNumber;
    private String phoneNumber;
    private String emailAddress;
    private String status;

    public Tenant() {}

    public Tenant(int id, String firstName, String lastName, String idOrPassportNumber,
                  String phoneNumber, String emailAddress, String status) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.idOrPassportNumber = idOrPassportNumber;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.status = status;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getIdOrPassportNumber() { return idOrPassportNumber; }
    public void setIdOrPassportNumber(String idOrPassportNumber) { this.idOrPassportNumber = idOrPassportNumber; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return getFullName() + " (" + idOrPassportNumber + ") - " + status;
    }
}