package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.dao.LeaseDAO;
import com.example.jamespropertysystem.dao.PaymentDAO;
import com.example.jamespropertysystem.dao.PropertyDAO;
import com.example.jamespropertysystem.dao.TenantDAO;
import com.example.jamespropertysystem.model.Lease;
import com.example.jamespropertysystem.model.Payment;
import com.example.jamespropertysystem.model.Property;
import com.example.jamespropertysystem.model.Tenant;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.io.FileWriter;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class ReportController implements Initializable {

    @FXML private ComboBox<String> reportTypeBox;
    @FXML private ComboBox<String> monthBox;
    @FXML private TextField yearField;
    @FXML private TableView<ObservableList<String>> reportTable;
    @FXML private TableColumn<ObservableList<String>, String> col1;
    @FXML private TableColumn<ObservableList<String>, String> col2;
    @FXML private TableColumn<ObservableList<String>, String> col3;
    @FXML private TableColumn<ObservableList<String>, String> col4;
    @FXML private Label stat1Label, stat2Label, stat3Label, stat4Label;
    @FXML private Label stat1Title, stat2Title, stat3Title, stat4Title;
    @FXML private Label statusLabel;

    private PropertyDAO propertyDAO = new PropertyDAO();
    private TenantDAO tenantDAO = new TenantDAO();
    private LeaseDAO leaseDAO = new LeaseDAO();
    private PaymentDAO paymentDAO = new PaymentDAO();

    // Store current report data for export
    private ObservableList<ObservableList<String>> currentData =
            FXCollections.observableArrayList();
    private String[] currentHeaders = {};

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        reportTypeBox.setItems(FXCollections.observableArrayList(
                "All Properties",
                "All Tenants",
                "Active Leases",
                "Expired Leases",
                "Overdue Payments",
                "Monthly Revenue",
                "Annual Revenue"
        ));
        reportTypeBox.setValue("All Properties");

        monthBox.setItems(FXCollections.observableArrayList(
                "1","2","3","4","5","6","7","8","9","10","11","12"));
        monthBox.setValue(String.valueOf(LocalDate.now().getMonthValue()));
        yearField.setText(String.valueOf(LocalDate.now().getYear()));

        setupTableColumns();
        loadSummaryStats();
        handleGenerate();
    }

    private void setupTableColumns() {
        col1.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().size() > 0 ? d.getValue().get(0) : ""));
        col2.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().size() > 1 ? d.getValue().get(1) : ""));
        col3.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().size() > 2 ? d.getValue().get(2) : ""));
        col4.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().size() > 3 ? d.getValue().get(3) : ""));
    }

    private void loadSummaryStats() {
        try {
            stat1Label.setText(String.valueOf(propertyDAO.getAllProperties().size()));
            stat1Title.setText("Total Properties");
            stat2Label.setText(String.valueOf(tenantDAO.getAllTenants().size()));
            stat2Title.setText("Total Tenants");
            stat3Label.setText(String.valueOf(leaseDAO.getAllLeases().size()));
            stat3Title.setText("Total Leases");
            LocalDate now = LocalDate.now();
            double revenue = paymentDAO.getTotalRevenueByMonth(
                    now.getMonthValue(), now.getYear());
            stat4Label.setText(String.format("N$%.2f", revenue));
            stat4Title.setText("This Month Revenue");
        } catch (Exception e) {
            System.err.println("Error loading stats: " + e.getMessage());
        }
    }

    @FXML
    private void handleReportChange() {
        handleGenerate();
    }

    @FXML
    private void handleGenerate() {
        String reportType = reportTypeBox.getValue();
        currentData = FXCollections.observableArrayList();

        switch (reportType) {
            case "All Properties" -> {
                currentHeaders = new String[]{"ID", "Type", "Address", "Status"};
                col1.setText("ID"); col2.setText("Type");
                col3.setText("Address"); col4.setText("Status");
                List<Property> properties = propertyDAO.getAllProperties();
                for (Property p : properties) {
                    currentData.add(FXCollections.observableArrayList(
                            String.valueOf(p.getId()), p.getPropertyType(),
                            p.getAddress(), p.getAvailabilityStatus()));
                }
                statusLabel.setText("Total properties: " + properties.size());
            }
            case "All Tenants" -> {
                currentHeaders = new String[]{"ID", "Full Name", "ID/Passport", "Status"};
                col1.setText("ID"); col2.setText("Full Name");
                col3.setText("ID/Passport"); col4.setText("Status");
                List<Tenant> tenants = tenantDAO.getAllTenants();
                for (Tenant t : tenants) {
                    currentData.add(FXCollections.observableArrayList(
                            String.valueOf(t.getId()), t.getFullName(),
                            t.getIdOrPassportNumber(), t.getStatus()));
                }
                statusLabel.setText("Total tenants: " + tenants.size());
            }
            case "Active Leases" -> {
                currentHeaders = new String[]{"ID", "Tenant", "Property", "End Date"};
                col1.setText("ID"); col2.setText("Tenant");
                col3.setText("Property"); col4.setText("End Date");
                List<Lease> leases = leaseDAO.getAllLeases().stream()
                        .filter(l -> l.isActive(LocalDate.now())).toList();
                for (Lease l : leases) {
                    currentData.add(FXCollections.observableArrayList(
                            String.valueOf(l.getId()), l.getTenantName(),
                            l.getPropertyAddress(), l.getEndDate().toString()));
                }
                statusLabel.setText("Active leases: " + leases.size());
            }
            case "Expired Leases" -> {
                currentHeaders = new String[]{"ID", "Tenant", "Property", "End Date"};
                col1.setText("ID"); col2.setText("Tenant");
                col3.setText("Property"); col4.setText("End Date");
                List<Lease> leases = leaseDAO.getAllLeases().stream()
                        .filter(l -> !l.isActive(LocalDate.now())).toList();
                for (Lease l : leases) {
                    currentData.add(FXCollections.observableArrayList(
                            String.valueOf(l.getId()), l.getTenantName(),
                            l.getPropertyAddress(), l.getEndDate().toString()));
                }
                statusLabel.setText("Expired leases: " + leases.size());
            }
            case "Overdue Payments" -> {
                currentHeaders = new String[]{"Tenant", "Property", "Amount", "Status"};
                col1.setText("Tenant"); col2.setText("Property");
                col3.setText("Amount"); col4.setText("Status");
                List<Payment> payments = paymentDAO.getOverduePayments();
                for (Payment p : payments) {
                    currentData.add(FXCollections.observableArrayList(
                            p.getTenantName(), p.getPropertyAddress(),
                            String.format("N$%.2f", p.getAmountPaid()),
                            p.getStatus()));
                }
                statusLabel.setText("Overdue payments: " + payments.size());
            }
            case "Monthly Revenue" -> {
                currentHeaders = new String[]{"Month", "Year", "Revenue", ""};
                col1.setText("Month"); col2.setText("Year");
                col3.setText("Revenue"); col4.setText("");
                try {
                    int month = Integer.parseInt(monthBox.getValue());
                    int year = Integer.parseInt(yearField.getText().trim());
                    double revenue = paymentDAO.getTotalRevenueByMonth(month, year);
                    currentData.add(FXCollections.observableArrayList(
                            monthBox.getValue(), String.valueOf(year),
                            String.format("N$%.2f", revenue), ""));
                    statusLabel.setText(String.format(
                            "Monthly revenue: N$%.2f", revenue));
                } catch (Exception e) {
                    statusLabel.setText("Invalid month/year.");
                }
            }
            case "Annual Revenue" -> {
                currentHeaders = new String[]{"Year", "Revenue", "", ""};
                col1.setText("Year"); col2.setText("Revenue");
                col3.setText(""); col4.setText("");
                try {
                    int year = Integer.parseInt(yearField.getText().trim());
                    double revenue = paymentDAO.getTotalRevenueByYear(year);
                    currentData.add(FXCollections.observableArrayList(
                            String.valueOf(year),
                            String.format("N$%.2f", revenue), "", ""));
                    statusLabel.setText(String.format(
                            "Annual revenue: N$%.2f", revenue));
                } catch (Exception e) {
                    statusLabel.setText("Invalid year.");
                }
            }
        }
        reportTable.setItems(currentData);
        loadSummaryStats();
    }

    @FXML
    private void handleExportCSV() {
        try {
            String filename = "Report_" + reportTypeBox.getValue().replace(" ", "_")
                    + "_" + LocalDate.now() + ".csv";
            FileWriter writer = new FileWriter(filename);

            // Write headers
            writer.write(String.join(",", currentHeaders) + "\n");

            // Write data
            for (ObservableList<String> row : currentData) {
                writer.write(String.join(",", row) + "\n");
            }
            writer.close();
            statusLabel.setText("CSV exported: " + filename);
            showInfo("CSV exported successfully!\nSaved as: " + filename);
        } catch (Exception e) {
            showError("Error exporting CSV: " + e.getMessage());
        }
    }

    @FXML
    private void handleExportPDF() {
        try {
            String filename = "Rental_Status_Report_" + LocalDate.now() + ".pdf";
            com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            com.itextpdf.text.pdf.PdfWriter.getInstance(document,
                    new java.io.FileOutputStream(filename));
            document.open();

            com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 18,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 12,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font normalFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 11);

            document.add(new com.itextpdf.text.Paragraph(
                    "JAMES PROPERTY HOLDINGS", titleFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "RENTAL STATUS REPORT", headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Generated: " + LocalDate.now(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Report Type: " + reportTypeBox.getValue(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            document.add(new com.itextpdf.text.Paragraph(" "));

            // Summary stats
            document.add(new com.itextpdf.text.Paragraph(
                    "SUMMARY", headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Total Properties: " + propertyDAO.getAllProperties().size(),
                    normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Total Tenants: " + tenantDAO.getAllTenants().size(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Total Leases: " + leaseDAO.getAllLeases().size(), normalFont));
            LocalDate now = LocalDate.now();
            double revenue = paymentDAO.getTotalRevenueByMonth(
                    now.getMonthValue(), now.getYear());
            document.add(new com.itextpdf.text.Paragraph(
                    "Monthly Revenue: N$" + String.format("%.2f", revenue),
                    normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));

            // Report data
            document.add(new com.itextpdf.text.Paragraph(
                    "REPORT DATA — " + reportTypeBox.getValue().toUpperCase(),
                    headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    String.join(" | ", currentHeaders), headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            for (ObservableList<String> row : currentData) {
                document.add(new com.itextpdf.text.Paragraph(
                        String.join(" | ", row), normalFont));
            }
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "James Property Holdings | Windhoek, Namibia", normalFont));
            document.close();
            statusLabel.setText("PDF exported: " + filename);
            showInfo("Report exported successfully!\nSaved as: " + filename);
        } catch (Exception e) {
            showError("Error exporting PDF: " + e.getMessage());
        }
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}