package com.example.jamespropertysystem.util;

public class Validator {

    // Names: letters, spaces, hyphens, apostrophes only
    public static boolean isValidName(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z\\s\\-']+");
    }

    // Address: letters, numbers, spaces, common punctuation
    public static boolean isValidAddress(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z0-9\\s,\\.\\-/#]+")
                && value.trim().length() >= 5;
    }

    // ERF number: letters and numbers only
    public static boolean isValidErfNumber(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z0-9\\s\\-/]+");
    }

    // Location: letters, spaces, hyphens only
    public static boolean isValidLocation(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z\\s\\-]+");
    }

    // Phone: digits, spaces, +, -, ()
    public static boolean isValidPhone(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[0-9\\s\\+\\-\\(\\)]+")
                && value.trim().replaceAll("[^0-9]", "").length() >= 7;
    }

    // Email: standard email format
    public static boolean isValidEmail(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches(
                "^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$");
    }

    // ID/Passport: letters and numbers only, min 6 chars
    public static boolean isValidIdNumber(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z0-9]+")
                && value.trim().length() >= 6;
    }

    // Positive number
    public static boolean isPositiveNumber(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            return Double.parseDouble(value.trim()) > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Positive integer
    public static boolean isPositiveInteger(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            return Integer.parseInt(value.trim()) > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Username: letters, numbers, underscore only, min 3 chars
    public static boolean isValidUsername(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return value.trim().matches("[a-zA-Z0-9_]+")
                && value.trim().length() >= 3;
    }

    // Password: min 6 chars, no spaces
    public static boolean isValidPassword(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        return !value.contains(" ") && value.length() >= 6;
    }

    // Helper to build error message
    public static String getNameError(String fieldName) {
        return fieldName + " must contain letters only (no numbers or special characters).";
    }

    public static String getAddressError() {
        return "Address must be at least 5 characters and contain only letters, numbers, spaces, commas, periods, hyphens, or slashes.";
    }

    public static String getPhoneError() {
        return "Phone number must contain at least 7 digits. Only numbers, spaces, +, -, and () are allowed.";
    }

    public static String getIdError() {
        return "ID/Passport must be at least 6 characters and contain only letters and numbers.";
    }

    public static String getNumberError(String fieldName) {
        return fieldName + " must be a valid number greater than zero.";
    }
}
