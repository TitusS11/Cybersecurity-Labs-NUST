package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.HelloApplication;
import com.example.jamespropertysystem.dao.UserDAO;
import com.example.jamespropertysystem.model.User;
import com.example.jamespropertysystem.util.SessionManager;
import com.example.jamespropertysystem.util.Validator;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private UserDAO userDAO = new UserDAO();

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        // Clear previous error
        errorLabel.setText("");

        // Validate username
        if (username.isEmpty()) {
            showError("Please enter your username.");
            return;
        }
        if (!Validator.isValidUsername(username)) {
            showError("Username can only contain letters, numbers, and underscores. No spaces or special characters.");
            return;
        }

        // Validate password
        if (password.isEmpty()) {
            showError("Please enter your password.");
            return;
        }
        if (!Validator.isValidPassword(password)) {
            showError("Password cannot contain spaces and must be at least 6 characters.");
            return;
        }

        // Attempt login
        User user = userDAO.login(username, password);
        if (user != null) {
            SessionManager.setCurrentUser(user);
            try {
                HelloApplication.showDashboard();
            } catch (Exception e) {
                showError("Error loading dashboard. Please try again.");
                e.printStackTrace();
            }
        } else {
            showError("Invalid username or password. Please try again.");
            passwordField.clear();
        }
    }

    private void showError(String message) {
        errorLabel.setText("⚠ " + message);
        errorLabel.setStyle("-fx-text-fill: #e53935; -fx-font-size: 12px;");
    }
}
