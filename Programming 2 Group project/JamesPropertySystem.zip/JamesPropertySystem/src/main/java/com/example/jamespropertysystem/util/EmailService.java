package com.example.jamespropertysystem.util;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;
import java.util.regex.Pattern;

public class EmailService {

    private static final String SENDER_EMAIL = "linnsonladollerz@gmail.com";
    private static final String SENDER_PASSWORD = "drbi ekxh uuwf iaoh";
    private static final String OWNER_EMAIL = "linnsonladollerz@gmail.com";

    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$");

    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    private static Session createSession() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

        return Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
            }
        });
    }

    public static void sendEmail(String toEmail, String subject, String body) {
        // Validate email before attempting to send
        if (!isValidEmail(toEmail)) {
            System.err.println("Invalid email address: " + toEmail);
            return;
        }

        Thread thread = new Thread(() -> {
            try {
                Session session = createSession();
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(SENDER_EMAIL));
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(toEmail));

                // Only CC owner if different from tenant
                if (!toEmail.equalsIgnoreCase(OWNER_EMAIL)) {
                    message.addRecipients(Message.RecipientType.CC,
                            InternetAddress.parse(OWNER_EMAIL));
                }

                message.setSubject(subject);
                message.setText(body);
                Transport.send(message);
                System.out.println("Email sent successfully to: " + toEmail);
            } catch (MessagingException e) {
                System.err.println("Email failed to: " + toEmail
                        + " — " + e.getMessage());
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    public static void sendLeaseConfirmation(String tenantEmail,
                                             String tenantName,
                                             String propertyAddress,
                                             String startDate,
                                             String endDate,
                                             double monthlyRent,
                                             double deposit) {
        if (!isValidEmail(tenantEmail)) return;
        String subject = "Lease Agreement Confirmation — James Property Holdings";
        String body = """
                Dear %s,

                Your lease agreement has been confirmed. Here are your details:

                Property:         %s
                Start Date:       %s
                End Date:         %s
                Monthly Rent:     N$%.2f
                Security Deposit: N$%.2f

                Please ensure your rent is paid on time to avoid penalties.

                Thank you for choosing James Property Holdings.

                Regards,
                James Property Holdings
                Windhoek, Namibia
                """.formatted(tenantName, propertyAddress, startDate,
                endDate, monthlyRent, deposit);
        sendEmail(tenantEmail, subject, body);
    }

    public static void sendPaymentReceipt(String tenantEmail,
                                          String tenantName,
                                          String propertyAddress,
                                          double amountPaid,
                                          double outstanding,
                                          String paymentDate,
                                          String status) {
        if (!isValidEmail(tenantEmail)) return;
        String subject = "Payment Receipt — James Property Holdings";
        String body = """
                Dear %s,

                We have received your payment. Here are the details:

                Property:            %s
                Amount Paid:         N$%.2f
                Payment Date:        %s
                Status:              %s
                Outstanding Balance: N$%.2f

                %s

                Thank you,
                James Property Holdings
                Windhoek, Namibia
                """.formatted(tenantName, propertyAddress, amountPaid,
                paymentDate, status, outstanding,
                outstanding > 0
                        ? "⚠ You have an outstanding balance of N$" +
                        String.format("%.2f", outstanding) +
                          ". Please settle this as soon as possible."
                        : "✓ Your account is fully settled.");
        sendEmail(tenantEmail, subject, body);
    }

    public static void sendPenaltyNotice(String tenantEmail,
                                         String tenantName,
                                         String propertyAddress,
                                         double penaltyAmount,
                                         double outstandingBalance) {
        if (!isValidEmail(tenantEmail)) return;
        String subject = "Late Payment Penalty Notice — James Property Holdings";
        String body = """
                Dear %s,

                This is a notice that a late payment penalty has been applied
                to your account.

                Property:            %s
                Penalty Applied:     N$%.2f
                Outstanding Balance: N$%.2f

                Please settle your outstanding balance immediately to avoid
                further penalties or lease termination.

                Regards,
                James Property Holdings
                Windhoek, Namibia
                """.formatted(tenantName, propertyAddress,
                penaltyAmount, outstandingBalance);
        sendEmail(tenantEmail, subject, body);
    }

    public static void sendTerminationNotice(String tenantEmail,
                                             String tenantName,
                                             String propertyAddress,
                                             String terminationDate) {
        if (!isValidEmail(tenantEmail)) return;
        String subject = "Lease Termination Notice — James Property Holdings";
        String body = """
                Dear %s,

                This is to inform you that your lease agreement has been
                terminated effective %s.

                Property: %s

                Please ensure the property is vacated and all outstanding
                balances are settled.

                Regards,
                James Property Holdings
                Windhoek, Namibia
                """.formatted(tenantName, terminationDate, propertyAddress);
        sendEmail(tenantEmail, subject, body);
    }

    public static void sendBlacklistNotice(String tenantEmail,
                                           String tenantName) {
        if (!isValidEmail(tenantEmail)) return;
        String subject = "Account Status Update — James Property Holdings";
        String body = """
                Dear %s,

                We regret to inform you that your account has been flagged
                and you have been blacklisted by James Property Holdings.

                This means you will no longer be eligible to enter into
                new lease agreements with us.

                If you believe this is an error or would like to discuss
                your account status, please contact us directly.

                Regards,
                James Property Holdings
                Windhoek, Namibia
                """.formatted(tenantName);
        sendEmail(tenantEmail, subject, body);
    }
}