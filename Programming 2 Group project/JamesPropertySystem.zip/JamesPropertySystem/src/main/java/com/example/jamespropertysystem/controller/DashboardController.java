package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.HelloApplication;
import com.example.jamespropertysystem.dao.LeaseDAO;
import com.example.jamespropertysystem.dao.PaymentDAO;
import com.example.jamespropertysystem.dao.PropertyDAO;
import com.example.jamespropertysystem.dao.TenantDAO;
import com.example.jamespropertysystem.dao.UserDAO;
import com.example.jamespropertysystem.model.User;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert;
import java.util.Optional;
import com.example.jamespropertysystem.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML private Label userLabel;
    @FXML private Label totalPropertiesLabel;
    @FXML private Label totalTenantsLabel;
    @FXML private Label totalLeasesLabel;
    @FXML private Label totalRevenueLabel;
    @FXML private StackPane contentArea;

    private PropertyDAO propertyDAO = new PropertyDAO();
    private TenantDAO tenantDAO = new TenantDAO();
    private LeaseDAO leaseDAO = new LeaseDAO();
    private PaymentDAO paymentDAO = new PaymentDAO();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (SessionManager.getCurrentUser() != null) {
            userLabel.setText("Logged in as: " + SessionManager.getCurrentUser().getUsername()
                    + " (" + SessionManager.getCurrentUser().getRole() + ")");
        }
        loadStats();
    }

    private void loadStats() {
        try {
            int totalProperties = propertyDAO.getAllProperties().size();
            totalPropertiesLabel.setText(String.valueOf(totalProperties));

            int totalTenants = tenantDAO.getAllTenants().size();
            totalTenantsLabel.setText(String.valueOf(totalTenants));

            int totalLeases = leaseDAO.getAllLeases().size();
            totalLeasesLabel.setText(String.valueOf(totalLeases));

            LocalDate now = LocalDate.now();
            double revenue = paymentDAO.getTotalRevenueByMonth(now.getMonthValue(), now.getYear());
            totalRevenueLabel.setText(String.format("N$%.2f", revenue));
        } catch (Exception e) {
            System.err.println("Error loading stats: " + e.getMessage());
        }
    }
    @FXML
    private void handleChangePassword() {
        // Verify current password first
        TextInputDialog currentPwdDialog = new TextInputDialog();
        currentPwdDialog.setTitle("Change Password");
        currentPwdDialog.setHeaderText("🔐 Verify Current Password");
        currentPwdDialog.setContentText("Enter your current password:");
        Optional<String> currentResult = currentPwdDialog.showAndWait();
        if (currentResult.isEmpty()) return;

        // Simple check against known password
        UserDAO userDAO = new UserDAO();
        User currentUser = SessionManager.getCurrentUser();
        if (userDAO.login(currentUser.getUsername(),
                currentResult.get().trim()) == null) {
            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Error");
            error.setHeaderText(null);
            error.setContentText("Current password is incorrect.");
            error.showAndWait();
            return;
        }

        // Ask for new password
        TextInputDialog newPwdDialog = new TextInputDialog();
        newPwdDialog.setTitle("Change Password");
        newPwdDialog.setHeaderText("Enter New Password");
        newPwdDialog.setContentText("New password (min 6 characters):");
        Optional<String> newResult = newPwdDialog.showAndWait();
        if (newResult.isEmpty() || newResult.get().trim().length() < 6) {
            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Error");
            error.setHeaderText(null);
            error.setContentText("Password must be at least 6 characters.");
            error.showAndWait();
            return;
        }

        // Confirm new password
        TextInputDialog confirmDialog = new TextInputDialog();
        confirmDialog.setTitle("Change Password");
        confirmDialog.setHeaderText("Confirm New Password");
        confirmDialog.setContentText("Re-enter new password:");
        Optional<String> confirmResult = confirmDialog.showAndWait();
        if (confirmResult.isEmpty() ||
                !confirmResult.get().trim().equals(newResult.get().trim())) {
            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Error");
            error.setHeaderText(null);
            error.setContentText("Passwords do not match.");
            error.showAndWait();
            return;
        }

        if (userDAO.changePassword(currentUser.getId(),
                newResult.get().trim())) {
            Alert success = new Alert(Alert.AlertType.INFORMATION);
            success.setTitle("Success");
            success.setHeaderText(null);
            success.setContentText("Password changed successfully. " +
                    "Please log in again with your new password.");
            success.showAndWait();
            SessionManager.logout();
            try {
                com.example.jamespropertysystem.HelloApplication.showLoginScreen();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Error");
            error.setHeaderText(null);
            error.setContentText("Failed to change password. Please try again.");
            error.showAndWait();
        }
    }

    @FXML
    private void showDashboardHome() {
        contentArea.getChildren().clear();
        VBox home = new VBox(25);
        home.setStyle("-fx-padding: 25;");

        VBox welcome = new VBox(4);
        javafx.scene.control.Label title = new javafx.scene.control.Label("Good day, Admin 👋");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #1a237e;");
        javafx.scene.control.Label sub = new javafx.scene.control.Label(
                "Here's what's happening with your properties today.");
        sub.setStyle("-fx-font-size: 13px; -fx-text-fill: #78909c;");
        welcome.getChildren().addAll(title, sub);
        home.getChildren().add(welcome);
        contentArea.getChildren().add(home);
        loadStats();
    }

    @FXML
    private void showProperties() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource(
                            "/com/example/jamespropertysystem/property-view.fxml"));
            javafx.scene.Parent view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            System.err.println("Error loading properties view: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void showTenants() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource(
                            "/com/example/jamespropertysystem/tenant-view.fxml"));
            javafx.scene.Parent view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            System.err.println("Error loading tenants view: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void showLeases() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource(
                            "/com/example/jamespropertysystem/lease-view.fxml"));
            javafx.scene.Parent view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            System.err.println("Error loading leases view: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void showPayments() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource(
                            "/com/example/jamespropertysystem/payment-view.fxml"));
            javafx.scene.Parent view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            System.err.println("Error loading payments view: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void showReports() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    HelloApplication.class.getResource(
                            "/com/example/jamespropertysystem/report-view.fxml"));
            javafx.scene.Parent view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (Exception e) {
            System.err.println("Error loading reports view: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout() {
        SessionManager.logout();
        try {
            HelloApplication.showLoginScreen();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}