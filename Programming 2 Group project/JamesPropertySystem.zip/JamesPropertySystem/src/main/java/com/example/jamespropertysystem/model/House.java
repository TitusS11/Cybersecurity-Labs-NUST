package com.example.jamespropertysystem.model;

public class House extends Property {

    private double plotSize;

    public House() {}

    public House(int id, double buildingFloorSize, String address, String erfNumber,
                 String location, double marketValue, double monthlyRentalCost,
                 String availabilityStatus, double plotSize) {
        super(id, "House", buildingFloorSize, address, erfNumber, location,
                marketValue, monthlyRentalCost, availabilityStatus);
        this.plotSize = plotSize;
    }

    @Override
    public String getTypeSpecificDetails() {
        return "Plot Size: " + plotSize + " m²";
    }

    public double getPlotSize() { return plotSize; }
    public void setPlotSize(double plotSize) { this.plotSize = plotSize; }
}
