package com.example.jamespropertysystem.util;

import com.example.jamespropertysystem.model.User;

public class SessionManager {

    private static User currentUser = null;

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static boolean verifyCurrentUserPassword(String password) {
        if (currentUser == null) return false;
        com.example.jamespropertysystem.dao.UserDAO userDAO =
                new com.example.jamespropertysystem.dao.UserDAO();
        return userDAO.verifyPassword(currentUser.getUsername(), password);
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static boolean isAdmin() {
        return currentUser != null && currentUser.getRole().equals("Admin");
    }

    public static void logout() {
        currentUser = null;
    }
}
