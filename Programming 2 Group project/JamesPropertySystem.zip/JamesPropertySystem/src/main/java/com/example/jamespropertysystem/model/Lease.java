package com.example.jamespropertysystem.model;

import java.time.LocalDate;
import java.time.Period;

public class Lease {

    private int id;
    private int propertyId;
    private int tenantId;
    private LocalDate startDate;
    private LocalDate endDate;
    private double monthlyRentAmount;
    private double securityDeposit;
    private int paymentDueDay;
    private int gracePeriodDays;
    private String latePenaltyRule;

    // For display purposes
    private String tenantName;
    private String propertyAddress;

    public Lease() {}

    public Lease(int id, int propertyId, int tenantId, LocalDate startDate, LocalDate endDate,
                 double monthlyRentAmount, double securityDeposit, int paymentDueDay,
                 int gracePeriodDays, String latePenaltyRule) {
        this.id = id;
        this.propertyId = propertyId;
        this.tenantId = tenantId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.monthlyRentAmount = monthlyRentAmount;
        this.securityDeposit = securityDeposit;
        this.paymentDueDay = paymentDueDay;
        this.gracePeriodDays = gracePeriodDays;
        this.latePenaltyRule = latePenaltyRule;
    }

    public int getLeaseDurationInMonths() {
        return Period.between(startDate, endDate).getMonths() +
                Period.between(startDate, endDate).getYears() * 12;
    }

    public boolean isActive(LocalDate onDate) {
        return !onDate.isBefore(startDate) && !onDate.isAfter(endDate);
    }

    public void terminateEarly(LocalDate newEndDate) {
        this.endDate = newEndDate;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPropertyId() { return propertyId; }
    public void setPropertyId(int propertyId) { this.propertyId = propertyId; }

    public int getTenantId() { return tenantId; }
    public void setTenantId(int tenantId) { this.tenantId = tenantId; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public double getMonthlyRentAmount() { return monthlyRentAmount; }
    public void setMonthlyRentAmount(double monthlyRentAmount) { this.monthlyRentAmount = monthlyRentAmount; }

    public double getSecurityDeposit() { return securityDeposit; }
    public void setSecurityDeposit(double securityDeposit) { this.securityDeposit = securityDeposit; }

    public int getPaymentDueDay() { return paymentDueDay; }
    public void setPaymentDueDay(int paymentDueDay) { this.paymentDueDay = paymentDueDay; }

    public int getGracePeriodDays() { return gracePeriodDays; }
    public void setGracePeriodDays(int gracePeriodDays) { this.gracePeriodDays = gracePeriodDays; }

    public String getLatePenaltyRule() { return latePenaltyRule; }
    public void setLatePenaltyRule(String latePenaltyRule) { this.latePenaltyRule = latePenaltyRule; }

    public String getTenantName() { return tenantName; }
    public void setTenantName(String tenantName) { this.tenantName = tenantName; }

    public String getPropertyAddress() { return propertyAddress; }
    public void setPropertyAddress(String propertyAddress) { this.propertyAddress = propertyAddress; }

    @Override
    public String toString() {
        return "Lease #" + id + " | " + propertyAddress + " | " + tenantName;
    }
}