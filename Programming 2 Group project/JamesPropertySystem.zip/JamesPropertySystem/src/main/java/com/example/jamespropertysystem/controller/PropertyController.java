package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.dao.PropertyDAO;
import com.example.jamespropertysystem.model.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.example.jamespropertysystem.util.Validator;
import javafx.fxml.FXML;
import com.example.jamespropertysystem.util.SessionManager;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class PropertyController implements Initializable {

    @FXML private TableView<Property> propertyTable;
    @FXML private TableColumn<Property, String> idCol;
    @FXML private TableColumn<Property, String> typeCol;
    @FXML private TableColumn<Property, String> addressCol;
    @FXML private TableColumn<Property, String> locationCol;
    @FXML private TableColumn<Property, String> rentCol;
    @FXML private TableColumn<Property, String> statusCol;
    @FXML private TableColumn<Property, String> detailsCol;
    @FXML private ComboBox<String> filterComboBox;
    @FXML private TextField searchField;
    @FXML private Label statusLabel;

    private PropertyDAO propertyDAO = new PropertyDAO();
    private ObservableList<Property> propertyList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupTableColumns();
        filterComboBox.setItems(FXCollections.observableArrayList(
                "All", "House", "Townhouse", "FlatApartment",
                "Available", "Occupied", "Maintenance"));
        filterComboBox.setValue("All");
        loadProperties();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.valueOf(d.getValue().getId())));
        typeCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getPropertyType()));
        addressCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getAddress()));
        locationCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getLocation()));
        rentCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getMonthlyRentalCost())));
        detailsCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getTypeSpecificDetails()));

        // Color coded status column
        statusCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getAvailabilityStatus()));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    switch (item) {
                        case "Available" ->
                                setStyle("-fx-text-fill: #2e7d32; -fx-font-weight: bold;");
                        case "Occupied" ->
                                setStyle("-fx-text-fill: #b71c1c; -fx-font-weight: bold;");
                        case "Maintenance" ->
                                setStyle("-fx-text-fill: #e65100; -fx-font-weight: bold;");
                        default -> setStyle("");
                    }
                }
            }
        });
    }

    private void loadProperties() {
        statusLabel.setText("Loading...");
        Thread thread = new Thread(() -> {
            List<Property> properties = propertyDAO.getAllProperties();
            javafx.application.Platform.runLater(() -> {
                propertyList.setAll(properties);
                propertyTable.setItems(propertyList);
                statusLabel.setText("Total: " + properties.size() + " properties");
            });
        });
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    private void handleFilter() {
        String filter = filterComboBox.getValue();
        List<Property> all = propertyDAO.getAllProperties();
        if (filter == null || filter.equals("All")) {
            propertyList.setAll(all);
        } else {
            propertyList.setAll(all.stream()
                    .filter(p -> p.getPropertyType().equals(filter)
                            || p.getAvailabilityStatus().equals(filter))
                    .toList());
        }
        propertyTable.setItems(propertyList);
        statusLabel.setText("Showing: " + propertyList.size() + " properties");
    }

    @FXML
    private void handleSearch() {
        String search = searchField.getText().toLowerCase();
        List<Property> all = propertyDAO.getAllProperties();
        propertyList.setAll(all.stream()
                .filter(p -> p.getAddress().toLowerCase().contains(search)
                        || p.getLocation().toLowerCase().contains(search))
                .toList());
        propertyTable.setItems(propertyList);
    }

    @FXML
    private void handleAddProperty() {
        showPropertyDialog(null);
    }

    @FXML
    private void handleEditProperty() {
        Property selected = propertyTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a property to edit.");
            return;
        }
        showPropertyDialog(selected);
    }

    @FXML
    private void handleDeleteProperty() {
        Property selected = propertyTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a property to delete.");
            return;
        }

        // Admin password confirmation
        TextInputDialog pwdDialog = new TextInputDialog();
        pwdDialog.setTitle("Admin Confirmation");
        pwdDialog.setHeaderText("🔐 Admin Password Required");
        pwdDialog.setContentText("Enter password to confirm delete:");
        Optional<String> pwdResult = pwdDialog.showAndWait();
        if (pwdResult.isEmpty() ||
                !SessionManager.verifyCurrentUserPassword(pwdResult.get().trim())) {
            showError("Incorrect password. Delete cancelled.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Property");
        confirm.setHeaderText("Delete " + selected.getAddress() + "?");
        confirm.setContentText("This action cannot be undone.");
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            if (propertyDAO.deleteProperty(selected.getId())) {
                loadProperties();
                statusLabel.setText("Property deleted successfully.");
            } else {
                showError("Cannot delete this property. It may have active leases.\n" +
                        "Please delete the associated lease first.");
            }
        }
    }

    private void showPropertyDialog(Property existing) {
        Dialog<Property> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add New Property" : "Edit Property");
        dialog.setHeaderText(existing == null
                ? "Fill in the property details below"
                : "Update property details");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        ComboBox<String> typeBox = new ComboBox<>(FXCollections.observableArrayList(
                "House", "Townhouse", "FlatApartment"));
        TextField addressField = new TextField();
        TextField erfField = new TextField();
        TextField locationField = new TextField();
        TextField sizeField = new TextField();
        TextField marketValueField = new TextField();
        TextField rentField = new TextField();
        ComboBox<String> statusBox = new ComboBox<>(FXCollections.observableArrayList(
                "Available", "Occupied", "Maintenance"));
        TextField plotSizeField = new TextField();
        TextField unitNumberField = new TextField();
        TextField floorLevelField = new TextField();
        CheckBox backyard = new CheckBox("Has Backyard");
        CheckBox elevator = new CheckBox("Has Elevator Access");

        // Set placeholders
        addressField.setPromptText("e.g. 12 Independence Ave");
        erfField.setPromptText("e.g. ERF 1234");
        locationField.setPromptText("e.g. Katutura");
        sizeField.setPromptText("e.g. 120.5");
        marketValueField.setPromptText("e.g. 850000");
        rentField.setPromptText("e.g. 5500");
        plotSizeField.setPromptText("e.g. 500 (House only)");
        unitNumberField.setPromptText("e.g. Unit 3");
        floorLevelField.setPromptText("e.g. 2 (Flat only)");

        if (existing != null) {
            typeBox.setValue(existing.getPropertyType());
            addressField.setText(existing.getAddress());
            erfField.setText(existing.getErfNumber());
            locationField.setText(existing.getLocation());
            sizeField.setText(String.valueOf(existing.getBuildingFloorSize()));
            marketValueField.setText(String.valueOf(existing.getMarketValue()));
            rentField.setText(String.valueOf(existing.getMonthlyRentalCost()));
            statusBox.setValue(existing.getAvailabilityStatus());
            if (existing instanceof House h)
                plotSizeField.setText(String.valueOf(h.getPlotSize()));
            if (existing instanceof Townhouse t) {
                unitNumberField.setText(t.getUnitNumber());
                backyard.setSelected(t.isHasBackyard());
            }
            if (existing instanceof FlatApartment f) {
                unitNumberField.setText(f.getUnitNumber());
                floorLevelField.setText(String.valueOf(f.getFloorLevel()));
                elevator.setSelected(f.isHasElevatorAccess());
                backyard.setSelected(f.isHasBackyard());
            }
        } else {
            typeBox.setValue("House");
            statusBox.setValue("Available");
        }

        grid.add(new Label("Property Type:"), 0, 0); grid.add(typeBox, 1, 0);
        grid.add(new Label("Address:*"), 0, 1); grid.add(addressField, 1, 1);
        grid.add(new Label("ERF Number:*"), 0, 2); grid.add(erfField, 1, 2);
        grid.add(new Label("Location:*"), 0, 3); grid.add(locationField, 1, 3);
        grid.add(new Label("Floor Size (m²):*"), 0, 4); grid.add(sizeField, 1, 4);
        grid.add(new Label("Market Value (N$):*"), 0, 5); grid.add(marketValueField, 1, 5);
        grid.add(new Label("Monthly Rent (N$):*"), 0, 6); grid.add(rentField, 1, 6);
        grid.add(new Label("Status:"), 0, 7); grid.add(statusBox, 1, 7);
        grid.add(new Label("Plot Size (House):"), 0, 8); grid.add(plotSizeField, 1, 8);
        grid.add(new Label("Unit Number:"), 0, 9); grid.add(unitNumberField, 1, 9);
        grid.add(new Label("Floor Level (Flat):"), 0, 10); grid.add(floorLevelField, 1, 10);
        grid.add(backyard, 1, 11);
        grid.add(elevator, 1, 12);

        Label note = new Label("* Required fields");
        note.setStyle("-fx-text-fill: #78909c; -fx-font-size: 11px;");
        grid.add(note, 1, 13);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setPrefWidth(450);

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                String address = addressField.getText().trim();
                String erf = erfField.getText().trim();
                String location = locationField.getText().trim();
                String sizeStr = sizeField.getText().trim();
                String marketStr = marketValueField.getText().trim();
                String rentStr = rentField.getText().trim();
                String type = typeBox.getValue();
                String status = statusBox.getValue();

                // Validate address
                if (!Validator.isValidAddress(address)) {
                    showError(Validator.getAddressError());
                    return null;
                }
                // Validate ERF
                if (!Validator.isValidErfNumber(erf)) {
                    showError("ERF number must contain only letters, numbers, hyphens or slashes.");
                    return null;
                }
                // Validate location
                if (!Validator.isValidLocation(location)) {
                    showError(Validator.getNameError("Location"));
                    return null;
                }
                // Validate size
                if (!Validator.isPositiveNumber(sizeStr)) {
                    showError(Validator.getNumberError("Floor size"));
                    return null;
                }
                // Validate market value
                if (!Validator.isPositiveNumber(marketStr)) {
                    showError(Validator.getNumberError("Market value"));
                    return null;
                }
                // Validate rent
                if (!Validator.isPositiveNumber(rentStr)) {
                    showError(Validator.getNumberError("Monthly rent"));
                    return null;
                }
                // Validate type specific fields
                if (type.equals("Townhouse") || type.equals("FlatApartment")) {
                    if (unitNumberField.getText().trim().isEmpty()) {
                        showError("Unit number is required for " + type + ".");
                        return null;
                    }
                }
                if (type.equals("FlatApartment")) {
                    if (!Validator.isPositiveInteger(floorLevelField.getText().trim())) {
                        showError("Floor level must be a valid number greater than zero.");
                        return null;
                    }
                }

                try {
                    double size = Double.parseDouble(sizeStr);
                    double marketValue = Double.parseDouble(marketStr);
                    double rent = Double.parseDouble(rentStr);
                    int id = existing != null ? existing.getId() : 0;

                    switch (type) {
                        case "House":
                            double plotSize = plotSizeField.getText().trim().isEmpty()
                                    ? 0 : Double.parseDouble(plotSizeField.getText().trim());
                            return new House(id, size, address, erf, location,
                                    marketValue, rent, status, plotSize);
                        case "Townhouse":
                            return new Townhouse(id, size, address, erf, location,
                                    marketValue, rent, status,
                                    unitNumberField.getText().trim(),
                                    backyard.isSelected());
                        default:
                            int floor = Integer.parseInt(floorLevelField.getText().trim());
                            return new FlatApartment(id, size, address, erf,
                                    location, marketValue, rent, status,
                                    unitNumberField.getText().trim(), floor,
                                    elevator.isSelected(), backyard.isSelected());
                    }
                } catch (NumberFormatException e) {
                    showError("Please enter valid numbers for size, market value and rent.");
                    return null;
                }
            }
            return null;
        });

        Optional<Property> result = dialog.showAndWait();
        result.ifPresent(property -> {
            if (property == null) return;
            boolean success;
            if (existing == null) {
                success = propertyDAO.addProperty(property);
                if (success) {
                    loadProperties();
                    statusLabel.setText("Property added successfully.");
                } else {
                    showError("Failed to save property. Please try again.");
                }
            } else {
                success = propertyDAO.updateProperty(property);
                if (success) {
                    loadProperties();
                    statusLabel.setText("Property updated successfully.");
                } else {
                    showError("Failed to update property. Please try again.");
                }
            }
        });
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}