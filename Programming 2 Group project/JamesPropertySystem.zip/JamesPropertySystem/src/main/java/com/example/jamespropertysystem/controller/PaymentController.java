package com.example.jamespropertysystem.controller;

import com.example.jamespropertysystem.dao.LeaseDAO;
import com.example.jamespropertysystem.dao.PaymentDAO;
import com.example.jamespropertysystem.model.Lease;
import com.example.jamespropertysystem.model.Payment;
import com.example.jamespropertysystem.util.EmailService;
import com.example.jamespropertysystem.util.SessionManager;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class PaymentController implements Initializable {

    @FXML private TableView<Payment> paymentTable;
    @FXML private TableColumn<Payment, String> idCol;
    @FXML private TableColumn<Payment, String> tenantCol;
    @FXML private TableColumn<Payment, String> propertyCol;
    @FXML private TableColumn<Payment, String> amountCol;
    @FXML private TableColumn<Payment, String> dateCol;
    @FXML private TableColumn<Payment, String> statusCol;
    @FXML private TableColumn<Payment, String> penaltyCol;
    @FXML private TableColumn<Payment, String> balanceCol;
    @FXML private ComboBox<String> statusFilterBox;
    @FXML private Label statusLabel;
    @FXML private Label totalLabel;

    private PaymentDAO paymentDAO = new PaymentDAO();
    private LeaseDAO leaseDAO = new LeaseDAO();
    private ObservableList<Payment> paymentList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupTableColumns();
        statusFilterBox.setItems(FXCollections.observableArrayList(
                "All", "Paid", "Late", "Pending"));
        statusFilterBox.setValue("All");
        loadPayments();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.valueOf(d.getValue().getId())));
        tenantCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getTenantName()));
        propertyCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getPropertyAddress()));
        amountCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getAmountPaid())));
        dateCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getPaymentDate().toString()));
        penaltyCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getPenaltyAmount())));
        balanceCol.setCellValueFactory(d -> new SimpleStringProperty(
                String.format("N$%.2f", d.getValue().getOutstandingBalance())));

        statusCol.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getStatus()));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    switch (item) {
                        case "Paid" ->
                                setStyle("-fx-text-fill: #2e7d32; -fx-font-weight: bold;");
                        case "Late" ->
                                setStyle("-fx-text-fill: #b71c1c; -fx-font-weight: bold;");
                        case "Pending" ->
                                setStyle("-fx-text-fill: #e65100; -fx-font-weight: bold;");
                        default -> setStyle("");
                    }
                }
            }
        });
    }

    private void loadPayments() {
        statusLabel.setText("Loading...");
        Thread thread = new Thread(() -> {
            List<Payment> payments = paymentDAO.getAllPayments();
            double totalOutstanding = payments.stream()
                    .mapToDouble(Payment::getOutstandingBalance).sum();
            javafx.application.Platform.runLater(() -> {
                paymentList.setAll(payments);
                paymentTable.setItems(paymentList);
                statusLabel.setText("Total: " + payments.size() + " payments");
                if (totalLabel != null) {
                    totalLabel.setText(String.format(
                            "Total Outstanding: N$%.2f", totalOutstanding));
                }
            });
        });
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    private void handleFilter() {
        String filter = statusFilterBox.getValue();
        List<Payment> all = paymentDAO.getAllPayments();
        if (filter == null || filter.equals("All")) {
            paymentList.setAll(all);
        } else {
            paymentList.setAll(all.stream()
                    .filter(p -> p.getStatus().equals(filter))
                    .toList());
        }
        paymentTable.setItems(paymentList);
        statusLabel.setText("Showing: " + paymentList.size() + " payments");
    }

    @FXML
    private void handleAddPayment() {
        List<Lease> leases = leaseDAO.getAllLeases();
        if (leases.isEmpty()) {
            showInfo("No leases found. Create a lease first.");
            return;
        }

        Dialog<Payment> dialog = new Dialog<>();
        dialog.setTitle("Record Payment");
        dialog.setHeaderText("Enter payment details");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        ComboBox<Lease> leaseBox = new ComboBox<>(
                FXCollections.observableArrayList(leases));
        TextField amountField = new TextField();
        DatePicker datePicker = new DatePicker(LocalDate.now());
        ComboBox<String> statusBox = new ComboBox<>(
                FXCollections.observableArrayList("Paid", "Late", "Pending"));
        statusBox.setValue("Paid");
        Label autoCalcLabel = new Label("Select a lease to auto-fill rent amount");
        autoCalcLabel.setStyle("-fx-text-fill: #546e7a; -fx-font-size: 11px;");

        leaseBox.setOnAction(e -> {
            Lease selected = leaseBox.getValue();
            if (selected != null) {
                amountField.setText(String.valueOf(selected.getMonthlyRentAmount()));
                LocalDate dueDate = datePicker.getValue().withDayOfMonth(
                        Math.min(selected.getPaymentDueDay(),
                                datePicker.getValue().lengthOfMonth()));
                LocalDate graceDate = dueDate.plusDays(selected.getGracePeriodDays());
                if (LocalDate.now().isAfter(graceDate)) {
                    statusBox.setValue("Late");
                    autoCalcLabel.setText("⚠ Payment is late! Penalty may apply.");
                    autoCalcLabel.setStyle("-fx-text-fill: #e53935; -fx-font-size: 11px;");
                } else {
                    statusBox.setValue("Paid");
                    autoCalcLabel.setText("✓ Payment is on time.");
                    autoCalcLabel.setStyle("-fx-text-fill: #2e7d32; -fx-font-size: 11px;");
                }
            }
        });

        grid.add(new Label("Lease:"), 0, 0); grid.add(leaseBox, 1, 0);
        grid.add(autoCalcLabel, 1, 1);
        grid.add(new Label("Amount Paid (N$):"), 0, 2); grid.add(amountField, 1, 2);
        grid.add(new Label("Payment Date:"), 0, 3); grid.add(datePicker, 1, 3);
        grid.add(new Label("Status:"), 0, 4); grid.add(statusBox, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                try {
                    Lease selectedLease = leaseBox.getValue();
                    if (selectedLease == null) {
                        showError("Please select a lease.");
                        return null;
                    }
                    if (amountField.getText().trim().isEmpty()) {
                        showError("Please enter the amount paid.");
                        return null;
                    }
                    double amount = Double.parseDouble(amountField.getText().trim());
                    if (amount <= 0) {
                        showError("Amount must be greater than zero.");
                        return null;
                    }
                    double outstanding = selectedLease.getMonthlyRentAmount() - amount;
                    if (outstanding < 0) outstanding = 0;
                    double penalty = 0;
                    String status = statusBox.getValue();
                    if (status.equals("Late")) {
                        penalty = selectedLease.getMonthlyRentAmount() * 0.10;
                        outstanding += penalty;
                    }
                    return new Payment(0, selectedLease.getId(), amount,
                            datePicker.getValue(), status, penalty, outstanding);
                } catch (NumberFormatException e) {
                    showError("Please enter a valid amount.");
                    return null;
                }
            }
            return null;
        });

        Optional<Payment> result = dialog.showAndWait();
        result.ifPresent(payment -> {
            if (paymentDAO.addPayment(payment)) {
                Lease selectedLease = leaseBox.getValue();
                new com.example.jamespropertysystem.dao.TenantDAO()
                        .getAllTenants().stream()
                        .filter(t -> t.getId() == selectedLease.getTenantId())
                        .findFirst()
                        .ifPresent(tenant -> {
                            if (tenant.getEmailAddress() != null
                                    && !tenant.getEmailAddress().isEmpty()) {
                                EmailService.sendPaymentReceipt(
                                        tenant.getEmailAddress(),
                                        tenant.getFullName(),
                                        selectedLease.getPropertyAddress(),
                                        payment.getAmountPaid(),
                                        payment.getOutstandingBalance(),
                                        payment.getPaymentDate().toString(),
                                        payment.getStatus()
                                );
                            }
                        });
                loadPayments();
                statusLabel.setText("Payment recorded successfully.");
            } else {
                showError("Failed to record payment.");
            }
        });
    }

    @FXML
    private void handleApplyPenalty() {
        Payment selected = paymentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a payment to apply penalty.");
            return;
        }

        List<Lease> leases = leaseDAO.getAllLeases();
        Lease lease = leases.stream()
                .filter(l -> l.getId() == selected.getLeaseId())
                .findFirst().orElse(null);

        double suggestedPenalty = lease != null
                ? lease.getMonthlyRentAmount() * 0.10 : 0;

        TextInputDialog penaltyDialog = new TextInputDialog(
                String.format("%.2f", suggestedPenalty));
        penaltyDialog.setTitle("Apply Late Penalty");
        penaltyDialog.setHeaderText("Apply late payment penalty");
        penaltyDialog.setContentText("Penalty amount (N$) — suggested 10%:");

        Optional<String> penaltyResult = penaltyDialog.showAndWait();
        penaltyResult.ifPresent(val -> {
            try {
                double penalty = Double.parseDouble(val.trim());
                selected.applyLatePenalty(penalty);
                if (paymentDAO.updatePayment(selected)) {
                    // Send penalty email
                    new com.example.jamespropertysystem.dao.TenantDAO()
                            .getAllTenants().stream()
                            .filter(t -> lease != null
                                    && t.getId() == lease.getTenantId())
                            .findFirst()
                            .ifPresent(tenant -> {
                                if (tenant.getEmailAddress() != null
                                        && !tenant.getEmailAddress().isEmpty()) {
                                    EmailService.sendPenaltyNotice(
                                            tenant.getEmailAddress(),
                                            tenant.getFullName(),
                                            selected.getPropertyAddress(),
                                            penalty,
                                            selected.getOutstandingBalance()
                                    );
                                }
                            });
                    loadPayments();
                    statusLabel.setText(String.format(
                            "Penalty of N$%.2f applied.", penalty));
                }
            } catch (NumberFormatException e) {
                showError("Invalid penalty amount.");
            }
        });
    }

    @FXML
    private void handleGenerateInvoice() {
        Payment selected = paymentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a payment to generate invoice.");
            return;
        }
        try {
            String filename = "Invoice_" + selected.getId() + "_"
                    + selected.getPaymentDate() + ".pdf";
            com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            com.itextpdf.text.pdf.PdfWriter.getInstance(document,
                    new java.io.FileOutputStream(filename));
            document.open();

            com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 18,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 12,
                    com.itextpdf.text.Font.BOLD);
            com.itextpdf.text.Font normalFont = new com.itextpdf.text.Font(
                    com.itextpdf.text.Font.FontFamily.HELVETICA, 11);

            document.add(new com.itextpdf.text.Paragraph(
                    "JAMES PROPERTY HOLDINGS", titleFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "PAYMENT INVOICE", headerFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "Invoice No: INV-" + selected.getId(), headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Date: " + selected.getPaymentDate(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "BILL TO:", headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Tenant: " + selected.getTenantName(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Property: " + selected.getPropertyAddress(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "PAYMENT DETAILS:", headerFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Amount Paid:         N$" + String.format("%.2f",
                            selected.getAmountPaid()), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Late Penalty:        N$" + String.format("%.2f",
                            selected.getPenaltyAmount()), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Outstanding Balance: N$" + String.format("%.2f",
                            selected.getOutstandingBalance()), normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "Status:              " + selected.getStatus(), normalFont));
            document.add(new com.itextpdf.text.Paragraph(" "));
            document.add(new com.itextpdf.text.Paragraph(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            document.add(new com.itextpdf.text.Paragraph(
                    "Thank you for your payment.", normalFont));
            document.add(new com.itextpdf.text.Paragraph(
                    "James Property Holdings | Windhoek, Namibia", normalFont));
            document.close();
            statusLabel.setText("Invoice saved: " + filename);
            showInfo("Invoice generated!\nSaved as: " + filename);
        } catch (Exception e) {
            showError("Error generating invoice: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeletePayment() {
        Payment selected = paymentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a payment to delete.");
            return;
        }

        if (!confirmAdminPassword()) {
            statusLabel.setText("Delete cancelled — incorrect password.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Payment");
        confirm.setHeaderText("Delete payment record #" + selected.getId() + "?");
        confirm.setContentText("This action cannot be undone.");
        Optional<ButtonType> confirmResult = confirm.showAndWait();
        if (confirmResult.isPresent() && confirmResult.get() == ButtonType.OK) {
            String sql = "DELETE FROM payments WHERE id=?";
            try (java.sql.PreparedStatement stmt =
                         com.example.jamespropertysystem.database.DBConnection
                                 .getConnection().prepareStatement(sql)) {
                stmt.setInt(1, selected.getId());
                stmt.executeUpdate();
                loadPayments();
                statusLabel.setText("Payment deleted successfully.");
            } catch (java.sql.SQLException e) {
                showError("Error deleting payment: " + e.getMessage());
            }
        }
    }

    private boolean confirmAdminPassword() {
        TextInputDialog pwdDialog = new TextInputDialog();
        pwdDialog.setTitle("Admin Confirmation");
        pwdDialog.setHeaderText("🔐 Admin Password Required");
        pwdDialog.setContentText("Enter your password to confirm:");
        Optional<String> pwdResult = pwdDialog.showAndWait();
        if (pwdResult.isPresent()) {
            return SessionManager.verifyCurrentUserPassword(
                    pwdResult.get().trim());
        }
        return false;
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}