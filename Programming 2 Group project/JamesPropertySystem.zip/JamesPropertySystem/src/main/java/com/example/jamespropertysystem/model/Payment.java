package com.example.jamespropertysystem.model;

import java.time.LocalDate;

public class Payment {

    private int id;
    private int leaseId;
    private double amountPaid;
    private LocalDate paymentDate;
    private String status;
    private double penaltyAmount;
    private double outstandingBalance;

    // For display purposes
    private String tenantName;
    private String propertyAddress;

    public Payment() {}

    public Payment(int id, int leaseId, double amountPaid, LocalDate paymentDate,
                   String status, double penaltyAmount, double outstandingBalance) {
        this.id = id;
        this.leaseId = leaseId;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.status = status;
        this.penaltyAmount = penaltyAmount;
        this.outstandingBalance = outstandingBalance;
    }

    public void applyLatePenalty(double penaltyAmount) {
        this.penaltyAmount = penaltyAmount;
        this.outstandingBalance += penaltyAmount;
        this.status = "Late";
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getLeaseId() { return leaseId; }
    public void setLeaseId(int leaseId) { this.leaseId = leaseId; }

    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getPenaltyAmount() { return penaltyAmount; }
    public void setPenaltyAmount(double penaltyAmount) { this.penaltyAmount = penaltyAmount; }

    public double getOutstandingBalance() { return outstandingBalance; }
    public void setOutstandingBalance(double outstandingBalance) { this.outstandingBalance = outstandingBalance; }

    public String getTenantName() { return tenantName; }
    public void setTenantName(String tenantName) { this.tenantName = tenantName; }

    public String getPropertyAddress() { return propertyAddress; }
    public void setPropertyAddress(String propertyAddress) { this.propertyAddress = propertyAddress; }

    @Override
    public String toString() {
        return "Payment #" + id + " | N$" + amountPaid + " | " + status;
    }
}
