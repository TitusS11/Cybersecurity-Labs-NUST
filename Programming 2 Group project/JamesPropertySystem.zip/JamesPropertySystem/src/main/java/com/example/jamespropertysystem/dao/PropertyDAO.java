package com.example.jamespropertysystem.dao;

import com.example.jamespropertysystem.database.DBConnection;
import com.example.jamespropertysystem.model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PropertyDAO {

    // Add a new property
    public boolean addProperty(Property property) {
        String sql = "INSERT INTO properties (property_type, building_floor_size, address, " +
                "erf_number, location, market_value, monthly_rental_cost, availability_status, " +
                "plot_size, unit_number, has_backyard, floor_level, has_elevator_access) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, property.getPropertyType());
            stmt.setDouble(2, property.getBuildingFloorSize());
            stmt.setString(3, property.getAddress());
            stmt.setString(4, property.getErfNumber());
            stmt.setString(5, property.getLocation());
            stmt.setDouble(6, property.getMarketValue());
            stmt.setDouble(7, property.getMonthlyRentalCost());
            stmt.setString(8, property.getAvailabilityStatus());

            if (property instanceof House h) {
                stmt.setDouble(9, h.getPlotSize());
                stmt.setNull(10, Types.VARCHAR);
                stmt.setNull(11, Types.BOOLEAN);
                stmt.setNull(12, Types.INTEGER);
                stmt.setNull(13, Types.BOOLEAN);
            } else if (property instanceof Townhouse t) {
                stmt.setNull(9, Types.NUMERIC);
                stmt.setString(10, t.getUnitNumber());
                stmt.setBoolean(11, t.isHasBackyard());
                stmt.setNull(12, Types.INTEGER);
                stmt.setNull(13, Types.BOOLEAN);
            } else if (property instanceof FlatApartment f) {
                stmt.setNull(9, Types.NUMERIC);
                stmt.setString(10, f.getUnitNumber());
                stmt.setBoolean(11, f.isHasBackyard());
                stmt.setInt(12, f.getFloorLevel());
                stmt.setBoolean(13, f.isHasElevatorAccess());
            }

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding property: " + e.getMessage());
            return false;
        }
    }

    // Get all properties
    public List<Property> getAllProperties() {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM properties";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                properties.add(mapResultSetToProperty(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching properties: " + e.getMessage());
        }
        return properties;
    }

    // Get only available properties
    public List<Property> getAvailableProperties() {
        List<Property> properties = new ArrayList<>();
        String sql = "SELECT * FROM properties WHERE availability_status = 'Available'";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                properties.add(mapResultSetToProperty(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching available properties: " + e.getMessage());
        }
        return properties;
    }

    // Update a property
    public boolean updateProperty(Property property) {
        String sql = "UPDATE properties SET building_floor_size=?, address=?, erf_number=?, " +
                "location=?, market_value=?, monthly_rental_cost=?, availability_status=?, " +
                "plot_size=?, unit_number=?, has_backyard=?, floor_level=?, has_elevator_access=? " +
                "WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setDouble(1, property.getBuildingFloorSize());
            stmt.setString(2, property.getAddress());
            stmt.setString(3, property.getErfNumber());
            stmt.setString(4, property.getLocation());
            stmt.setDouble(5, property.getMarketValue());
            stmt.setDouble(6, property.getMonthlyRentalCost());
            stmt.setString(7, property.getAvailabilityStatus());

            if (property instanceof House h) {
                stmt.setDouble(8, h.getPlotSize());
                stmt.setNull(9, Types.VARCHAR);
                stmt.setNull(10, Types.BOOLEAN);
                stmt.setNull(11, Types.INTEGER);
                stmt.setNull(12, Types.BOOLEAN);
            } else if (property instanceof Townhouse t) {
                stmt.setNull(8, Types.NUMERIC);
                stmt.setString(9, t.getUnitNumber());
                stmt.setBoolean(10, t.isHasBackyard());
                stmt.setNull(11, Types.INTEGER);
                stmt.setNull(12, Types.BOOLEAN);
            } else if (property instanceof FlatApartment f) {
                stmt.setNull(8, Types.NUMERIC);
                stmt.setString(9, f.getUnitNumber());
                stmt.setBoolean(10, f.isHasBackyard());
                stmt.setInt(11, f.getFloorLevel());
                stmt.setBoolean(12, f.isHasElevatorAccess());
            }

            stmt.setInt(13, property.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating property: " + e.getMessage());
            return false;
        }
    }

    // Delete a property
    public boolean deleteProperty(int id) {
        String sql = "DELETE FROM properties WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting property: " + e.getMessage());
            return false;
        }
    }

    // Update availability status
    public boolean updateAvailabilityStatus(int propertyId, String status) {
        String sql = "UPDATE properties SET availability_status=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, propertyId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating status: " + e.getMessage());
            return false;
        }
    }

    // Map database row to Property object
    private Property mapResultSetToProperty(ResultSet rs) throws SQLException {
        String type = rs.getString("property_type");
        int id = rs.getInt("id");
        double buildingFloorSize = rs.getDouble("building_floor_size");
        String address = rs.getString("address");
        String erfNumber = rs.getString("erf_number");
        String location = rs.getString("location");
        double marketValue = rs.getDouble("market_value");
        double monthlyRentalCost = rs.getDouble("monthly_rental_cost");
        String availabilityStatus = rs.getString("availability_status");

        switch (type) {
            case "House":
                House house = new House(id, buildingFloorSize, address, erfNumber, location,
                        marketValue, monthlyRentalCost, availabilityStatus,
                        rs.getDouble("plot_size"));
                return house;
            case "Townhouse":
                Townhouse townhouse = new Townhouse(id, buildingFloorSize, address, erfNumber,
                        location, marketValue, monthlyRentalCost, availabilityStatus,
                        rs.getString("unit_number"), rs.getBoolean("has_backyard"));
                return townhouse;
            default:
                FlatApartment flat = new FlatApartment(id, buildingFloorSize, address, erfNumber,
                        location, marketValue, monthlyRentalCost, availabilityStatus,
                        rs.getString("unit_number"), rs.getInt("floor_level"),
                        rs.getBoolean("has_elevator_access"), rs.getBoolean("has_backyard"));
                return flat;
        }
    }
}
