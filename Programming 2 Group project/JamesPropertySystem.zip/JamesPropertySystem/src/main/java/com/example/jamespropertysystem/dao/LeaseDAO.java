package com.example.jamespropertysystem.dao;

import com.example.jamespropertysystem.database.DBConnection;
import com.example.jamespropertysystem.model.Lease;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LeaseDAO {

    public boolean addLease(Lease lease) {
        String sql = "INSERT INTO leases (property_id, tenant_id, start_date, end_date, " +
                "monthly_rent_amount, security_deposit, payment_due_day, grace_period_days, " +
                "late_penalty_rule) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, lease.getPropertyId());
            stmt.setInt(2, lease.getTenantId());
            stmt.setDate(3, Date.valueOf(lease.getStartDate()));
            stmt.setDate(4, Date.valueOf(lease.getEndDate()));
            stmt.setDouble(5, lease.getMonthlyRentAmount());
            stmt.setDouble(6, lease.getSecurityDeposit());
            stmt.setInt(7, lease.getPaymentDueDay());
            stmt.setInt(8, lease.getGracePeriodDays());
            stmt.setString(9, lease.getLatePenaltyRule());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding lease: " + e.getMessage());
            return false;
        }
    }

    public List<Lease> getAllLeases() {
        List<Lease> leases = new ArrayList<>();
        String sql = "SELECT l.*, t.first_name, t.last_name, p.address " +
                "FROM leases l " +
                "JOIN tenants t ON l.tenant_id = t.id " +
                "JOIN properties p ON l.property_id = p.id";
        try (Statement stmt = DBConnection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Lease lease = mapResultSetToLease(rs);
                lease.setTenantName(rs.getString("first_name") + " " + rs.getString("last_name"));
                lease.setPropertyAddress(rs.getString("address"));
                leases.add(lease);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching leases: " + e.getMessage());
        }
        return leases;
    }

    public List<Lease> getLeasesByTenant(int tenantId) {
        List<Lease> leases = new ArrayList<>();
        String sql = "SELECT l.*, t.first_name, t.last_name, p.address " +
                "FROM leases l " +
                "JOIN tenants t ON l.tenant_id = t.id " +
                "JOIN properties p ON l.property_id = p.id " +
                "WHERE l.tenant_id = ?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, tenantId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Lease lease = mapResultSetToLease(rs);
                lease.setTenantName(rs.getString("first_name") + " " + rs.getString("last_name"));
                lease.setPropertyAddress(rs.getString("address"));
                leases.add(lease);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching tenant leases: " + e.getMessage());
        }
        return leases;
    }

    public boolean isPropertyOccupied(int propertyId) {
        String sql = "SELECT COUNT(*) FROM leases WHERE property_id = ? " +
                "AND end_date >= CURRENT_DATE";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, propertyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking property occupancy: " + e.getMessage());
        }
        return false;
    }

    public boolean updateLease(Lease lease) {
        String sql = "UPDATE leases SET start_date=?, end_date=?, monthly_rent_amount=?, " +
                "security_deposit=?, payment_due_day=?, grace_period_days=?, " +
                "late_penalty_rule=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(lease.getStartDate()));
            stmt.setDate(2, Date.valueOf(lease.getEndDate()));
            stmt.setDouble(3, lease.getMonthlyRentAmount());
            stmt.setDouble(4, lease.getSecurityDeposit());
            stmt.setInt(5, lease.getPaymentDueDay());
            stmt.setInt(6, lease.getGracePeriodDays());
            stmt.setString(7, lease.getLatePenaltyRule());
            stmt.setInt(8, lease.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating lease: " + e.getMessage());
            return false;
        }
    }

    public boolean terminateLease(int leaseId, java.time.LocalDate newEndDate) {
        String sql = "UPDATE leases SET end_date=? WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(newEndDate));
            stmt.setInt(2, leaseId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error terminating lease: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteLease(int id) {
        String sql = "DELETE FROM leases WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting lease: " + e.getMessage());
            return false;
        }
    }

    private Lease mapResultSetToLease(ResultSet rs) throws SQLException {
        return new Lease(
                rs.getInt("id"),
                rs.getInt("property_id"),
                rs.getInt("tenant_id"),
                rs.getDate("start_date").toLocalDate(),
                rs.getDate("end_date").toLocalDate(),
                rs.getDouble("monthly_rent_amount"),
                rs.getDouble("security_deposit"),
                rs.getInt("payment_due_day"),
                rs.getInt("grace_period_days"),
                rs.getString("late_penalty_rule")
        );
    }
}
