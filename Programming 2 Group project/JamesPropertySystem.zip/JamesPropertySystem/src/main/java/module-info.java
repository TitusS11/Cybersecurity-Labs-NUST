module com.example.jamespropertysystem {
    requires javafx.controls;
    requires jakarta.mail;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;
    requires itextpdf;

    opens com.example.jamespropertysystem to javafx.fxml;
    opens com.example.jamespropertysystem.controller to javafx.fxml;
    exports com.example.jamespropertysystem;
}